package com.huawei.friend.service;

public interface FriendService {
    public int addFriend(String userId,String friendId);
}
