package com.itheima.service.impl;

import com.github.pagehelper.PageHelper;
import com.itheima.domain.Orders;
import com.itheima.mapper.OrderMapper;
import com.itheima.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderServiceImpl implements OrderService {
    @Autowired
    private OrderMapper orderMapper;
    @Override
    public List<Orders> findAll(Integer pageNum,Integer pageSize) throws Exception {
        //添加分页功能
        PageHelper.startPage(pageNum,pageSize);
        return orderMapper.findAll();

    }

    @Override
    public List<Orders> findByCondition(String oNum) throws Exception {
        return orderMapper.findByorderName(oNum);
    }
}
