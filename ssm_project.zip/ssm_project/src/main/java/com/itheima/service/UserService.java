package com.itheima.service;


import com.itheima.domain.Users;

import java.util.List;

public interface UserService {
    List<Users> findAll() throws Exception;
}
