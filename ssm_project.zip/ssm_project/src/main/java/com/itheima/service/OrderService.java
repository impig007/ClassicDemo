package com.itheima.service;

import com.itheima.domain.Orders;

import java.util.List;

public interface OrderService {
    List<Orders> findAll(Integer pageNum,Integer pageSize)throws Exception;

    List<Orders> findByCondition(String oNum)throws Exception;
}
