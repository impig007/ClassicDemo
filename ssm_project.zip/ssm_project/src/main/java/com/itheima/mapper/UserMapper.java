package com.itheima.mapper;


import com.itheima.domain.Users;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserMapper {
    @Select("select * from users")
    List<Users> findAll() throws Exception;
}
