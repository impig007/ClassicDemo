package com.itheima.mapper;

import com.itheima.domain.Orders;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface OrderMapper {
    @Select("select * from orders")
    List<Orders> findAll()throws Exception;
    @Select("select * from orders where orderNum=#{oNum}")
    List<Orders> findByorderName(String oNum)throws Exception;
}
