package com.itheima.controller;

import com.github.pagehelper.PageInfo;
import com.itheima.domain.Product;
import com.itheima.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/product")
public class ProductController {
    @Autowired
    private ProductService productService;
    @RequestMapping("/findAll")
    public String findAll(@RequestParam(value = "pageNum",required = false,defaultValue = "1") Integer pageNum,
                          @RequestParam(value = "pageSize",required = false,defaultValue = "1") Integer pageSize, Model model) throws Exception {
        List<Product> productList = productService.findAll(pageNum,pageSize);
        //获取pageinfo相当于之前的pageBean对象，里面分装了很多的分页信息
        PageInfo<Product> pageInfo = new PageInfo<Product>(productList);
        model.addAttribute("pageInfo",pageInfo);
        return "product-list";
    }
}
