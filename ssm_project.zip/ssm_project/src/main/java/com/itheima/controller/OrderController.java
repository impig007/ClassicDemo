package com.itheima.controller;

import com.github.pagehelper.PageInfo;
import com.itheima.domain.Orders;

import com.itheima.service.OrderService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderService orderService;
    @RequestMapping("/findAll")
    public String findAll(@RequestParam(value = "pageNum",required = false,defaultValue = "1")Integer pageNum,
                          @RequestParam(value = "pageSize",required = false,defaultValue = "1")Integer pageSize ,Model model) throws Exception {

        List<Orders> ordersList = orderService.findAll(pageNum,pageSize);
        //获取pageInfo对象
        PageInfo<Orders> pageInfo = new PageInfo<>(ordersList);
        model.addAttribute("pageInfo",pageInfo);

        return "orders-list";
    }
    @RequestMapping("/findByCondition")
    public String findByCondition(String oNum,Model model) throws Exception {
        System.out.println(oNum);
       List<Orders> ordersList = orderService.findByCondition(oNum);
        PageInfo<Orders> pageInfo = new PageInfo<>(ordersList);
        model.addAttribute("pageInfo",pageInfo);
        return "orders-list";
    }
}
