package com.itheima.test;


import com.itheima.domain.Users;
import com.itheima.service.UserService;
import org.junit.Test;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class mytest {
    @Test
    public void mybatisTest() throws Exception {
        //
        ClassPathXmlApplicationContext app = new ClassPathXmlApplicationContext("spring.xml");
        UserService userService = app.getBean(UserService.class);
        List<Users> all = userService.findAll();
        System.out.println(all);
    }
}
