package com.changgou.util;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;

import java.io.IOException;

/*
* 发送短信工具类
* */
public class SMSUtils {

    public static void sendShortMessage(String orderId) throws IOException {
        HttpClient client = new HttpClient();
        PostMethod post = new PostMethod("http://gbk.api.smschinese.cn");
        post.addRequestHeader("Content-Type","application/x-www-form-urlencoded;charset=gbk");//在头文件中设置转码
        NameValuePair[] data ={
                new NameValuePair("Uid", " 天空之城一片云"), //用户名
                new NameValuePair("Key", "d41d8cd98f00b204e980"), //短信秘钥
                new NameValuePair("smsMob","19956502351"),//接收短信的手机号17756446525
                new NameValuePair("smsMob","17756446525"),//接收短信的手机号
                new NameValuePair("smsText","畅购22期：订单号为"+orderId+"，提醒您发货，请及时发货！")};//短信内容
        post.setRequestBody(data);

        client.executeMethod(post);
        Header[] headers = post.getResponseHeaders();
        int statusCode = post.getStatusCode();
        System.out.println("statusCode:"+statusCode);
        for(Header h : headers)
        {
            System.out.println(h.toString());
        }
        String result = new String(post.getResponseBodyAsString().getBytes("gbk"));
        System.out.println(result); //打印返回消息状态

        post.releaseConnection();
    }
}
