package com.changgou.entity;

import java.io.Serializable;

/**
 * @Author:admin
 * @Date:2020/4/4 18:50
 */
public class PageParam implements Serializable {
    public String currentPage;
    public String pageSize;
    public String receiverContactOrMobile;
    public String id;
    public String orderStatus;
    public String sourceType;

    public String getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(String currentPage) {
        this.currentPage = currentPage;
    }

    public String getPageSize() {
        return pageSize;
    }

    public void setPageSize(String pageSize) {
        this.pageSize = pageSize;
    }

    public String getReceiverContactOrMobile() {
        return receiverContactOrMobile;
    }

    public void setReceiverContactOrMobile(String receiverContactOrMobile) {
        this.receiverContactOrMobile = receiverContactOrMobile;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }
}
