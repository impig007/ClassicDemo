package com.changgou.entity;

import java.io.Serializable;
import java.util.List;

/**
 * @Author:admin
 * @Date:2020/4/4 18:29
 */
public class OrderInfo implements Serializable {

    /**
     * id : 1243842623802798080  订单编号
     * username : heima           用户账号
     * receiverContact : 大枪       收货人
     * receiverMobile : 13955498293     手机号
     * totalMoney : 236700          订单金额
     * payType : 1                  支付方式  0 其他支付 1微信支付
     * sourceType : 1               订单来源  1:web，2：app，3：微信公众号，4：微信小程序  5 H5手机页面
     * orderStatus : 0              订单状态  0未发货 1已发货
     */
    private String id;
    private String username;
    private String receiverContact;
    private String receiverMobile;
    private int totalMoney;
    private String payType;
    private String sourceType;
    private String orderStatus;



    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getReceiverContact() {
        return receiverContact;
    }

    public void setReceiverContact(String receiverContact) {
        this.receiverContact = receiverContact;
    }

    public String getReceiverMobile() {
        return receiverMobile;
    }

    public void setReceiverMobile(String receiverMobile) {
        this.receiverMobile = receiverMobile;
    }

    public int getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(int totalMoney) {
        this.totalMoney = totalMoney;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }


}
