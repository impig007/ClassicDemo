package com.changgou.report.service;

import com.changgou.order.pojo.Order;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

public interface ReportService {
    void exportOrderReport(List<Order> fackDate, HttpServletResponse response);
}
