package com.changgou.report.dao;

import com.changgou.order.pojo.Order;
import tk.mybatis.mapper.common.Mapper;

public interface ReportMapper extends Mapper<Order> {
}
