package com.changgou.report.controller;

import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.order.feign.OrderFeign;
import org.apache.commons.math3.geometry.partitioning.BoundaryProjection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/echarts")
public class EchartsController {
    @Autowired
    private OrderFeign orderFeign;

    @PostMapping("/getOrderPieData")
    public Result<Map<String,Object>> getOrderPieData(@RequestBody Map timeMap){
        Map<String,Object> resultMap = new HashMap<>();
        List<Map<String,Object>> orderCountList = new ArrayList<>();
        //根据开始和结束时间,订单状态查询
        //待付款订单list
        orderCountList.add(getCountMap(timeMap,"待付款","0"));
        //待发货订单list
        orderCountList.add(getCountMap(timeMap,"待发货","0"));
        //已经发货订单
        orderCountList.add(getCountMap(timeMap,"已经发货","1"));
        //以完成订单
        orderCountList.add( getCountMap(timeMap,"已经完成","2"));
        //以关闭订单
        orderCountList.add(getCountMap(timeMap,"已经关闭","4"));

        List<String> orderTypeList  = new ArrayList<>();
        orderTypeList.add("待付款");
        orderTypeList.add("待发货");
        orderTypeList.add("已经发货");
        orderTypeList.add("已经完成");
        orderTypeList.add("已经关闭");
        resultMap.put("orderTypeList",orderTypeList);
        resultMap.put("orderCountList",orderCountList);
        return new Result<Map<String,Object>>(true, StatusCode.OK,"分装数据成功",resultMap);
    }

    private Map<String,Object> getCountMap(Map timeMap, String type,String statucode) {
        timeMap.put("order_status",statucode);
        Integer data = orderFeign.findEchartsData(timeMap).getData();
        Map<String,Object> tempMap =new HashMap<>();
        tempMap.put("name",type);
        tempMap.put("value",data);
        return tempMap;
    }


}
