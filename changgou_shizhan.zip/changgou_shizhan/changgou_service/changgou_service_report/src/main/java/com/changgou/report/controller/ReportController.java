package com.changgou.report.controller;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.order.pojo.Order;
import com.changgou.report.service.ReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/report")
public class ReportController {
    @Autowired
    private ReportService reportService;
    @RequestMapping("/exportOrderReport")
    public Result exportOrderReport(HttpServletResponse response){
        //制作假数据
        List<Order> fackDate  = new ArrayList<>();
        Order orderDate = new Order();
        for (int i = 0; i <3 ; i++) {
            orderDate.setId("1111");
            orderDate.setUsername("张三");
            orderDate.setReceiverContact("李四");
            orderDate.setReceiverMobile("19233344444");
            orderDate.setTotalMoney(2000);
            orderDate.setPayType("微信");
            orderDate.setSourceType("1"); //让对接的判断是几并处理成文字方式，set进list
            orderDate.setOrderStatus("2");
            fackDate.add(orderDate);
        }
        //调用导出业务
        reportService.exportOrderReport(fackDate,response);
        return new Result(true, StatusCode.OK,"导出excel成功");
    }
}
