package com.changgou.report.service.impl;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.io.IoUtil;
import cn.hutool.poi.excel.ExcelUtil;
import cn.hutool.poi.excel.ExcelWriter;
import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.order.pojo.Order;
import com.changgou.report.service.ReportService;
import org.springframework.stereotype.Service;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ReportServiceImpl implements ReportService {


    @Override
    public void exportOrderReport(List<Order> fackDate, HttpServletResponse response) {
        ExcelWriter writer = ExcelUtil.getWriter(true);//写出xlsx
        //sheet主体
        ArrayList<Object> excelDateList = CollUtil.newArrayList();
        //表头行
        List<String> head = CollUtil.newArrayList("订单编号","收户账号","收货人","手机号","订单金额","支付方式","订单来源","订单状态");
        excelDateList.add(head);
        for (Order order : fackDate) {
            List<String> row = CollUtil.newArrayList(order.getId(), order.getUsername(), order.getReceiverContact(), order.getReceiverMobile(),String.valueOf(order.getTotalMoney()),order.getPayType(),order.getSourceType(),order.getOrderStatus());
            excelDateList.add(row);
        }
        //合并单元格后的标题行，使用默认标题样式
        writer.merge(excelDateList.size() - 1, "测试标题");
        //一次性写出内容，强制输出标题
        writer.write(excelDateList, true);
        response.setContentType("application/vnd.ms-excel");//代表的是Excel文件类型
        response.setHeader("content-Disposition", "attachment;filename=report.xlsx");//指定以附件形式进行下载
        try {
            ServletOutputStream out = response.getOutputStream();
            writer.flush(out, true);
            writer.close();
            IoUtil.close(out);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
