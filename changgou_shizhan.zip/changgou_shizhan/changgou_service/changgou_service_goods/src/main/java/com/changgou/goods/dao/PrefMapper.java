package com.changgou.goods.dao;

import com.changgou.goods.pojo.Pref;
import tk.mybatis.mapper.common.Mapper;

public interface PrefMapper extends Mapper<Pref> {

}
