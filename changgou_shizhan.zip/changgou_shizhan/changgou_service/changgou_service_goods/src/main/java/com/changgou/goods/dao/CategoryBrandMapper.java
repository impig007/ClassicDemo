package com.changgou.goods.dao;

import com.changgou.goods.pojo.CategoryBrand;
import tk.mybatis.mapper.common.Mapper;

public interface CategoryBrandMapper extends Mapper<CategoryBrand> {
}
