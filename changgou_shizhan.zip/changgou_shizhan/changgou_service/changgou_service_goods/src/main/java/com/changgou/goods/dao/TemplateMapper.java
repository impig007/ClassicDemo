package com.changgou.goods.dao;

import com.changgou.goods.pojo.Template;
import tk.mybatis.mapper.common.Mapper;

public interface TemplateMapper extends Mapper<Template> {

}
