package com.changgou.evaluate.controller;

import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.evaluate.pojo.Evaluate;
import com.changgou.evaluate.pojo.EvaluateInfo;
import com.changgou.evaluate.service.EvaluateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@RestController
@RequestMapping("/evaluate")
public class EvaluateController {

    @Autowired
    private EvaluateService evaluateService;

    /**
     * 添加评论
     */
    @PostMapping("/add")
    public Result add(@RequestBody Evaluate evaluate){
        evaluateService.add(evaluate);
        return new Result(true,StatusCode.OK,"添加成功");
    }


    /**
     * 根据skuId读取评论信息
     * @param skuIdList
     * @return
     */
    @GetMapping("/findBySkuId")
    public Result<List<Evaluate>> findBySkuId(@RequestParam List<String> skuIdList){
        List<Evaluate> evaluateList=evaluateService.findBySkuId(skuIdList);
        return new Result<>(true, StatusCode.OK,"查询成功",evaluateList);
    }

    @GetMapping("/grade")
    public Result<List<EvaluateInfo>> grade(@RequestParam String spuId,@RequestParam Integer grade){
        List<EvaluateInfo> evaluateInfoList= evaluateService.grade(spuId,grade);
        return new Result<>(true,StatusCode.OK,"查询成功",evaluateInfoList);
    }

}
