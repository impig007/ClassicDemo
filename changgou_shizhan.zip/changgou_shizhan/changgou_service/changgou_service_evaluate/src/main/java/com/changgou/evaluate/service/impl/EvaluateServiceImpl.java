package com.changgou.evaluate.service.impl;

import com.alibaba.fastjson.JSON;
import com.changgou.entity.Result;
import com.changgou.evaluate.pojo.Evaluate;
import com.changgou.evaluate.config.RabbitMQConfig;
import com.changgou.evaluate.config.TokenDecode;
import com.changgou.evaluate.pojo.EvaluateInfo;
import com.changgou.evaluate.service.EvaluateService;
import com.changgou.goods.feign.SkuFeign;
import com.changgou.goods.pojo.Sku;
import com.changgou.order.feign.OrderItemFeign;
import com.changgou.order.pojo.OrderItem;
import com.changgou.user.feign.UserFeign;
import com.changgou.user.pojo.User;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


@Service
public class EvaluateServiceImpl implements EvaluateService {

    @Autowired
    private TokenDecode tokenDecode;

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private SkuFeign skuFeign;

    @Autowired
    private UserFeign userFeign;



    /**
     * 添加评论
     *
     * @param evaluate
     */
    @Override
    public void add(Evaluate evaluate) {
        String username = tokenDecode.getUserInfo().get("username");

        User user = userFeign.findUserInfo(username);
        evaluate.setIntegral(user.getPoints());
        int length = username.length()-4;
        username="****"+username.substring(length);
        evaluate.setUsername(username);
        evaluate.setDate(new Date());



        mongoTemplate.save(evaluate);

        rabbitTemplate.convertAndSend(RabbitMQConfig.GOODS_UP_EXCHANGE,RabbitMQConfig.PAGE_CREATE_QUEUE,evaluate.getSkuId());

    }

    /**
     * 根据skuId读取评论信息
     *
     * @param skuIdList
     * @return
     */
    @Override
    public List<Evaluate> findBySkuId(List<String> skuIdList) {

        Query query=new Query();
        query.addCriteria(Criteria.where("skuId").in(skuIdList));
        query.with(Sort.by(
                Sort.Order.desc("date")
        ));

        List<Evaluate> evaluateList = mongoTemplate.find(query, Evaluate.class);
        return evaluateList;
    }

    @Override
    public List<EvaluateInfo> grade(String spuId, Integer grade) {

        List<Sku> skuList = skuFeign.findSkuListBySpuId(spuId);
        //获取sku评论信息
        List<String> skuIdList=new ArrayList<>();
        for (Sku sku : skuList) {
            skuIdList.add(sku.getId());
        }

        Query query=new Query();
        if(grade==1) {
            query.addCriteria(Criteria.where("skuId").in(skuIdList));
            query.with(Sort.by(
                    Sort.Order.desc("date")
            ));
        }else if(grade==78){
            query.addCriteria(Criteria.where("skuId").in(skuIdList).and("grade").is(78));
            query.with(Sort.by(
                    Sort.Order.desc("date")
            ));
        }else if(grade==47){
            query.addCriteria(Criteria.where("skuId").in(skuIdList).and("grade").is(47));
            query.with(Sort.by(
                    Sort.Order.desc("date")
            ));
        }else if(grade==16){
            query.addCriteria(Criteria.where("skuId").in(skuIdList).and("grade").is(16));
            query.with(Sort.by(
                    Sort.Order.desc("date")
            ));
        }


        List<Evaluate> evaluateList = mongoTemplate.find(query, Evaluate.class);

        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm");
        List<EvaluateInfo> evaluateInfoList=new ArrayList<>();

        for (Evaluate evaluate : evaluateList) {
            String evaluateString = JSON.toJSONString(evaluate);
            EvaluateInfo evaluateInfo = JSON.parseObject(evaluateString, EvaluateInfo.class);
            evaluateInfo.setDateString(simpleDateFormat.format(evaluate.getDate()));
            evaluateInfoList.add(evaluateInfo);
        }

        return evaluateInfoList;
    }
}
