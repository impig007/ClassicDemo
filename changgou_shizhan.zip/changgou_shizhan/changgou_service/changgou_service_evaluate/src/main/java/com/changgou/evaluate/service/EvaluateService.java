package com.changgou.evaluate.service;

import com.changgou.evaluate.pojo.Evaluate;
import com.changgou.evaluate.pojo.EvaluateInfo;

import java.util.List;

public interface EvaluateService {

    /**
     * 添加评论
     * @param evaluate
     */
    void add(Evaluate evaluate);

    /**
     * 根据skuId读取评论信息
     * @param skuIdList
     * @return
     */
    List<Evaluate> findBySkuId(List<String> skuIdList);


    List<EvaluateInfo> grade(String spuId, Integer grade);
}
