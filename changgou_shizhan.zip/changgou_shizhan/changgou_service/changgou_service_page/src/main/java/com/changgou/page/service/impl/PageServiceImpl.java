package com.changgou.page.service.impl;

import com.alibaba.fastjson.JSON;
import com.changgou.entity.Result;
import com.changgou.evaluate.pojo.Evaluate;
import com.changgou.evaluate.pojo.EvaluateInfo;
import com.changgou.goods.feign.CategoryFeign;
import com.changgou.goods.feign.SkuFeign;
import com.changgou.goods.feign.SpuFeign;
import com.changgou.goods.pojo.Category;
import com.changgou.goods.pojo.Sku;
import com.changgou.goods.pojo.Spu;
import com.changgou.page.service.PageService;
import com.changgou.page.until.ImageCompressUtil;
import com.changgou.page.until.UUIDUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PageServiceImpl implements PageService {

    @Value("${pagepath}")
    private String pagepath;

    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private SkuFeign skuFeign;

    @Override
    public void generateHtml(String spuId) {

        Result<Sku> skuResult = skuFeign.findById(spuId);
        Sku sku = skuResult.getData();
        if(sku!=null){
            spuId=sku.getSpuId();
        }

        //1.获取context对象,用于存储商品的相关数据
        Context context = new Context();

        //获取静态化页面的相关数据
        Map<String,Object> itemData= this.getItemData(spuId);
        context.setVariables(itemData);

        //2.获取商品详情页面的存储位置
        File dir = new File(pagepath);
        //3.判断当前存储位置的文件夹是否存在,如果不存在,则新建
        if (!dir.exists()){
            dir.mkdirs();
        }
        //4.定义输出流,完成文件的生成
        File file = new File(dir+"/"+spuId+".html");
        Writer out = null;
        try{
            out = new PrintWriter(file);
            //生成静态化页面
            /**
             * 1. 模板名称
             * 2.context
             * 3.输出流
             */
            templateEngine.process("item",context,out);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            //5.关闭流
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    @Autowired
    private SpuFeign spuFeign;

    @Autowired
    private CategoryFeign categoryFeign;

    @Autowired
    private MongoTemplate mongoTemplate;


    //压缩图保存路径
    @Value("${smallPicPath}")
    private String smallPicPath;

    //获取静态化页面的相关数据
    private Map<String, Object> getItemData(String spuId) {
        Map<String, Object> resultMap = new HashMap<>();
        //获取spu
        Spu spu = spuFeign.findSpuById(spuId).getData();
        resultMap.put("spu",spu);
        //获取图片信息
        if (spu != null){
            if (StringUtils.isNotEmpty(spu.getImages())){
                resultMap.put("imageList",spu.getImages().split(","));
                //获取原始图片
                String [] bigPics=spu.getImages().split(",");
                //最终缩略图
                String [] smallPic=new String[bigPics.length];
                Integer i=0;
                for(String bigPic : bigPics){
                    //设置缩略图路径
                    String smallPicUrl=smallPicPath+"\\"+ UUIDUtil.genUUID32()+".jpg";
                    //压缩图片
                    try {
//                        smallPic[i] = ImageCompressUtil.saveMinPhoto(bigPic,smallPicUrl,139, 0.9d);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                resultMap.put("imageList",smallPic);
            }
        }
        //获取商品的分类信息
        Category category1 = categoryFeign.findById(spu.getCategory1Id()).getData();
        resultMap.put("category1",category1);

        Category category2 = categoryFeign.findById(spu.getCategory2Id()).getData();
        resultMap.put("category2",category2);

        Category category3 = categoryFeign.findById(spu.getCategory3Id()).getData();
        resultMap.put("category3",category3);

        //获取sku的相关信息
        List<Sku> skuList = skuFeign.findSkuListBySpuId(spuId);
        resultMap.put("skuList",skuList);

        //获取商品规格信息
        resultMap.put("specificationList",JSON.parseObject(spu.getSpecItems(),Map.class));

        //获取sku评论信息
        List<String> skuIdList=new ArrayList<>();
        for (Sku sku : skuList) {
            skuIdList.add(sku.getId());
        }

        Query query=new Query();
        query.addCriteria(Criteria.where("skuId").in(skuIdList));
        query.with(Sort.by(
                Sort.Order.desc("date")
        ));

        List<Evaluate> evaluateList = mongoTemplate.find(query, Evaluate.class);



        SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd HH:mm");
        List<EvaluateInfo> evaluateInfoList=new ArrayList<>();


        Query query1=new Query();
        query1.addCriteria(Criteria.where("skuId").in(skuIdList));
        //总记录数
        long evaluateSum = mongoTemplate.count(query1, Evaluate.class);

        Query query2=new Query();
        query2.addCriteria(Criteria.where("skuId").in(skuIdList).and("grade").is(78));
        //好评数
        long goodEvaluate = mongoTemplate.count(query2, Evaluate.class);

        Query query3=new Query();
        query3.addCriteria(Criteria.where("skuId").in(skuIdList).and("grade").is(47));
        //中评数
        long mediumEvaluate = mongoTemplate.count(query3, Evaluate.class);

        Query query4=new Query();
        query4.addCriteria(Criteria.where("skuId").in(skuIdList).and("grade").is(16));
        //差评
        long inferiorEvaluate = mongoTemplate.count(query4, Evaluate.class);


        for (Evaluate evaluate : evaluateList) {
            String evaluateString = JSON.toJSONString(evaluate);
            EvaluateInfo evaluateInfo = JSON.parseObject(evaluateString, EvaluateInfo.class);
            evaluateInfo.setDateString(simpleDateFormat.format(evaluate.getDate()));
            evaluateInfoList.add(evaluateInfo);
        }

        List<EvaluateInfo> evaluateInfoGoodList=new ArrayList<>();
        List<EvaluateInfo> evaluateInfoMediumList=new ArrayList<>();
        List<EvaluateInfo> evaluateInfoInferiorList=new ArrayList<>();
        for (EvaluateInfo evaluateInfo : evaluateInfoList) {
            Integer grade = evaluateInfo.getGrade();
            if(grade==78){
                evaluateInfoGoodList.add(evaluateInfo);
            }else if(grade==47){
                evaluateInfoMediumList.add(evaluateInfo);
            }else {
                evaluateInfoInferiorList.add(evaluateInfo);
            }
        }




        //总评论相关信息
        resultMap.put("evaluateInfoList",evaluateInfoList);
        //好评相关信息
        resultMap.put("evaluateInfoGoodList",evaluateInfoGoodList);
        //中评相关信息
        resultMap.put("evaluateInfoMediumList",evaluateInfoMediumList);
        //差评相关信息
        resultMap.put("evaluateInfoInferiorList",evaluateInfoInferiorList);

        //商品评论总数
        resultMap.put("evaluateSum",evaluateSum);
        //商品好评数
        resultMap.put("goodEvaluate",goodEvaluate);
        //商品中评数
        resultMap.put("mediumEvaluate",mediumEvaluate);
        //商品差评数
        resultMap.put("inferiorEvaluate",inferiorEvaluate);

        NumberFormat numberFormat = NumberFormat.getInstance();
        numberFormat.setMaximumFractionDigits(2);
        String result = numberFormat.format((float) (goodEvaluate + mediumEvaluate) / (float) evaluateSum * 100);

        resultMap.put("result",result+"%");

        return resultMap;
    }
}
