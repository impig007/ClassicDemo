package com.changgou.page.until;

import java.util.UUID;

/**
 */
public enum UUIDUtil {
    ;

    /**
     * 生成32位UUID
     *
     * @return
     */
    public static String genUUID32() {
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
}
