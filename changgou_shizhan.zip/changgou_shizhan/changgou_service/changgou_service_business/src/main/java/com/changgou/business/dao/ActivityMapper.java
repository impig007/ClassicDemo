package com.changgou.business.dao;

import com.changgou.business.pojo.Activity;
import tk.mybatis.mapper.common.Mapper;

public interface ActivityMapper extends Mapper<Activity> {

}
