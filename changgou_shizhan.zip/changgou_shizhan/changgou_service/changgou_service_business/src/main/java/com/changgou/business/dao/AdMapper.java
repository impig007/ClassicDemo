package com.changgou.business.dao;

import com.changgou.business.pojo.Ad;
import tk.mybatis.mapper.common.Mapper;

public interface AdMapper extends Mapper<Ad> {

}
