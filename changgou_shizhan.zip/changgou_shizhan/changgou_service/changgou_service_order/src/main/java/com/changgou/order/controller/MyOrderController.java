package com.changgou.order.controller;


import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.order.config.TokenDecode;
import com.changgou.order.pojo.MyOrder;
import com.changgou.order.pojo.OrderLog;
import com.changgou.order.service.MyOrderService;
import com.changgou.order.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/orderCenter")
public class MyOrderController {

    @Autowired
    private MyOrderService myOrderService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private TokenDecode tokenDecode;



    @GetMapping("/findOrders")
    public Result< Map<String,Object>> findOrders(){
        Map<String,Object> map=new HashMap<>();
        String username = tokenDecode.getUserInfo().get("username");
        List<MyOrder> orders = myOrderService.findOrders(username);
        map.put("username",username);
        map.put("myOrderList",orders);
        return  new Result(true, StatusCode.OK,"查询所有订单成功",map);
    }

    //根据id取消订单
    @RequestMapping("/cancleOrder")
    public Result cancleOrder(@RequestParam("orderId") String orderId){
           myOrderService.cancleOrder(orderId);
           return  new Result(true, StatusCode.OK,"取消订单成功");
    }

    //根据订单id 查询订单日志是否发货
    @GetMapping("/toBeShipped/{orderId}")
    public Result toBeShipped(@PathVariable("orderId") String orderId){
        Integer count = myOrderService.toBeShipped(orderId);

        return  new Result(true, StatusCode.OK,"",count);
    }
   //根据用户名查询待发货订单
    @GetMapping("/findtoBeShipped")
    public Result<Map<String,Object>> findtoBeShipped(){
        Map<String,Object> map=new HashMap<>();
        String username = tokenDecode.getUserInfo().get("username");
        List<MyOrder> myOrderList = myOrderService.findtoBeShipped(username);
        map.put("username",username);
        map.put("myOrderList",myOrderList);

        return  new Result<>(true, StatusCode.OK,"查询待收货订单成功",map);

    }

    //根据订单id,手动确认收货
    @GetMapping("/confirmtask/{orderId}")
    public Result  confirmtask(@PathVariable("orderId") String orderId){
        String username = tokenDecode.getUserInfo().get("username");
        orderService.confirmTask(orderId,username);

        return  new Result<>(true, StatusCode.OK,"确认收货操作成功");

    }
    //根据用户名查询待收货订单
    @GetMapping("/find2BeReceived")
    public Result<Map<String,Object>> find2BeReceived(){
        Map<String,Object> map=new HashMap<>();
        String username = tokenDecode.getUserInfo().get("username");
        List<MyOrder> myOrderList = myOrderService.find2BeReceived(username);
        map.put("username",username);
        map.put("myOrderList",myOrderList);
        return  new Result(true, StatusCode.OK,"查询所有订单成功",map);
    }

    //根据用户名查询待付款订单
    @GetMapping("/find2BePaid")
    public Result<Map<String,Object>> find2BePaid(){
        Map<String,Object> map=new HashMap<>();
        String username = tokenDecode.getUserInfo().get("username");
        List<MyOrder> myOrderList = myOrderService.find2BePaid(username);
        map.put("username",username);
        map.put("myOrderList",myOrderList);
        return  new Result(true, StatusCode.OK,"查询待付款订单成功",map);
    }


}
