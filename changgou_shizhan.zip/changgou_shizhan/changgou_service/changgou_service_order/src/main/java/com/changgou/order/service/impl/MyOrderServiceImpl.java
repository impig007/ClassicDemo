package com.changgou.order.service.impl;

import com.alibaba.fescar.spring.annotation.GlobalTransactional;
import com.changgou.goods.feign.SkuFeign;
import com.changgou.order.config.TokenDecode;
import com.changgou.order.dao.OrderItemMapper;
import com.changgou.order.dao.OrderLogMapper;
import com.changgou.order.dao.OrderMapper;
import com.changgou.order.pojo.MyOrder;
import com.changgou.order.pojo.Order;
import com.changgou.order.pojo.OrderItem;
import com.changgou.order.pojo.OrderLog;
import com.changgou.order.service.MyOrderService;
import com.changgou.util.IdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class MyOrderServiceImpl implements MyOrderService {
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private OrderItemMapper orderItemMapper;
    @Autowired
    private IdWorker idWorker;
    @Autowired
    private OrderLogMapper orderLogMapper;
    @Autowired
    private SkuFeign skuFeign;




    @Override
    public List<MyOrder> findOrders(String username) {

        List<MyOrder> myOrderList=new ArrayList<>();
        //1根据姓名查询订单
        Example example =new Example(Order.class);
        example.setOrderByClause("create_time desc");
        Example.Criteria criteria = example.createCriteria();

        criteria.andEqualTo("username",username);
        List<Order> orderList = orderMapper.selectByExample(example);


        if(orderList!=null&&orderList.size()>0){
            //遍历orderList
            for (Order order : orderList) {
                MyOrder myOrder=new MyOrder();
                //根据order_id为order的主键,查询所有orderItem
                Example example2=new Example(OrderItem.class);
                Example.Criteria example2Criteria = example2.createCriteria();
                example2Criteria.andEqualTo("orderId",order.getId());
                List<OrderItem> orderItems = orderItemMapper.selectByExample(example2);
                myOrder.setOrder(order);
                myOrder.setOrderItemList(orderItems);
                myOrderList.add(myOrder);

            }
        }

        return myOrderList;
    }



    @Override
    @Transactional
    public void cancleOrder(String orderId) {
        Order order = orderMapper.selectByPrimaryKey(orderId);
        if (order == null){
            throw new RuntimeException("订单不存在!");
        }
        if (!"0".equals(order.getPayStatus())){
            System.out.println("已付款,不可取消");
            return;
        }
        order.setUpdateTime(new Date());
        order.setPayStatus("0");
        order.setOrderStatus("4");
        orderMapper.updateByPrimaryKeySelective(order);

        //新增订单日志
        OrderLog orderLog = new OrderLog();
        orderLog.setId(idWorker.nextId()+"");
        orderLog.setOperater("admin");
        orderLog.setOperateTime(new Date());
        orderLog.setPayStatus("0");
        orderLog.setOrderStatus("4");
        orderLog.setOrderId(order.getId());
        orderLogMapper.insert(orderLog);

        //恢复商品的库存
        OrderItem _orderItem = new OrderItem();
        _orderItem.setOrderId(order.getId());
        List<OrderItem> orderItemList = orderItemMapper.select(_orderItem);

        for (OrderItem orderItem : orderItemList) {
            skuFeign.resumeStockNum(orderItem.getSkuId(),orderItem.getNum());
        }
    }


        //根据订单id 查询订单日志判断是否发货
        @Override
        public Integer toBeShipped(String orderId) {
            //根据订单ID查询订单是否存在
            OrderLog orderLog = new OrderLog();
          //  待发货：订单支付成功时,订单状态为1（已支付），订单支付状态为1（已支付），订单发货状态为0（未发货）
            orderLog.setOrderId(orderId);
            //orderLog.setPayStatus("1");
           // orderLog.setOrderStatus("1");
            orderLog.setConsignStatus("1"); //已发货
            int count = orderLogMapper.selectCount(orderLog);
            if (count>0){
                return  count;
            }

          return  null;
        }

        //根据用户名查询待发货订单
    @Override
    public List<MyOrder> findtoBeShipped(String username) {

        //1根据姓名查询订单
        Example example =new Example(Order.class);
        example.setOrderByClause("create_time desc");
        Example.Criteria criteria = example.createCriteria();
//待发货：订单支付成功时,订单状态为1（已支付），订单支付状态为1（已支付），订单发货状态为0（未发货）
        criteria.andEqualTo("username",username);
        criteria.andEqualTo("orderStatus","1");
        criteria.andEqualTo("payStatus","1");
        criteria.andEqualTo("consignStatus","0");
        //符合条件的待发货订单
        List<Order> orderList = orderMapper.selectByExample(example);

        if(orderList!=null&&orderList.size()>0){
            List<MyOrder> myOrderList = this.getMyOrder(orderList);
            return myOrderList;
        }

        return null;
    }

    @Override
    public List<MyOrder> find2BeReceived(String username) {
        //1根据姓名查询订单
        Example example =new Example(Order.class);
        example.setOrderByClause("create_time desc");
        Example.Criteria criteria = example.createCriteria();

        //待收货：订单发货时，订单状态为2已发货，订单支付状态为1已支付，订单发货状态为1已发货
        criteria.andEqualTo("orderStatus","2");
        criteria.andEqualTo("payStatus","1");
        criteria.andEqualTo("consignStatus","1");
        criteria.andEqualTo("username",username);
        //符合条件的待收货订单
        List<Order> orderList = orderMapper.selectByExample(example);
        if(orderList!=null&&orderList.size()>0){
            List<MyOrder> myOrderList = this.getMyOrder(orderList);
            return myOrderList;
        }

        return null;
    }




    @Override
    public List<MyOrder> find2BePaid(String username) {
        //1根据姓名查询订单
        Example example =new Example(Order.class);
        example.setOrderByClause("create_time desc");
        Example.Criteria criteria = example.createCriteria();

        //待收货：订单发货时，订单状态为2已发货，订单支付状态为1已支付，订单发货状态为1已发货
        criteria.andEqualTo("orderStatus","0");
        criteria.andEqualTo("payStatus","0");
        criteria.andEqualTo("consignStatus","0");
        criteria.andEqualTo("username",username);
        //符合条件的待收货订单
        List<Order> orderList = orderMapper.selectByExample(example);
        if(orderList!=null&&orderList.size()>0){
            List<MyOrder> myOrderList = this.getMyOrder(orderList);
            return myOrderList;
        }

        return null;
    }



    public List<MyOrder> getMyOrder( List<Order> orderList){
        List<MyOrder> myOrderList=new ArrayList<>();
        for (Order order : orderList) {
            MyOrder myOrder=new MyOrder();
            //根据order_id为order的主键,查询所有orderItem
            Example example2=new Example(OrderItem.class);
            Example.Criteria example2Criteria = example2.createCriteria();
            example2Criteria.andEqualTo("orderId",order.getId());
            List<OrderItem> orderItems = orderItemMapper.selectByExample(example2);
            myOrder.setOrder(order);
            myOrder.setOrderItemList(orderItems);
            myOrderList.add(myOrder);
        }
      return  myOrderList;
    }
}

