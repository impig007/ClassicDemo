package com.changgou.order.service;

import com.changgou.order.pojo.MyOrder;
import com.changgou.order.pojo.OrderLog;

import java.util.List;

public interface MyOrderService {
    //查询所有订单
    List<MyOrder> findOrders(String  username);

    //取消订单
    void cancleOrder(String orderId);

    //订单待发货查询
    Integer toBeShipped(String orderId);
//根据用户名查询待发货订单
    List<MyOrder> findtoBeShipped(String username);

    //根据用户名查询待收货订单
    List<MyOrder> find2BeReceived(String username);
    //根据用户名查询待付款订单
    List<MyOrder> find2BePaid(String username);
}
