package com.changgou.order.dao;

import com.changgou.order.pojo.OrderItem;
import org.apache.ibatis.annotations.Update;
import tk.mybatis.mapper.common.Mapper;

public interface OrderItemMapper extends Mapper<OrderItem> {

    /**
     * 修改数据
     * @param orderItemId
     */
    @Update("UPDATE tb_order_item SET buyer_rate=1 where id=#{orderItemId}")
    void updateSkuId(String orderItemId);
}
