package com.changgou.order.service;

import com.changgou.order.pojo.Task;

public interface TaskService {

    void delTask(Task task);
}
