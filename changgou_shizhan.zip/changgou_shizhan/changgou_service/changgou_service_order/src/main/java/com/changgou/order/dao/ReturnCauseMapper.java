package com.changgou.order.dao;

import com.changgou.order.pojo.ReturnCause;
import tk.mybatis.mapper.common.Mapper;

public interface ReturnCauseMapper extends Mapper<ReturnCause> {

}
