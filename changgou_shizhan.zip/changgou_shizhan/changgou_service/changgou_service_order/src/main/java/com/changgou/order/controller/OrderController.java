package com.changgou.order.controller;
import com.alibaba.fastjson.JSON;

import com.changgou.entity.PageParam;
import com.changgou.entity.PageResult;
import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.order.config.TokenDecode;
import com.changgou.order.pojo.OrderResult;
import com.changgou.order.service.OrderService;
import com.changgou.order.pojo.Order;
import com.changgou.order.util.HttpUtils;
import com.github.pagehelper.Page;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;



@RestController
@CrossOrigin
@RequestMapping("/order")
public class OrderController {


    @Autowired
    private OrderService orderService;

    /**
     * 查询全部数据
     *
     * @return
     */
    @GetMapping
    public Result<List<Order>> findAll() {
        List<Order> orderList = orderService.findAll();
        return new Result(true, StatusCode.OK, "查询成功", orderList);
    }

    /***
     * 根据ID查询数据
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public Result<Order> findById(@PathVariable("id") String id) {
        Order order = orderService.findById(id);
        return new Result(true, StatusCode.OK, "查询成功", order);
    }

    @Autowired
    private TokenDecode tokenDecode;

    /***
     * 新增数据
     * @param order
     * @return
     */
    @PostMapping
    public Result add(@RequestBody Order order) {
        //获取登录人名称
        String username = tokenDecode.getUserInfo().get("username");
        order.setUsername(username);
        String orderId = orderService.add(order);
        return new Result(true, StatusCode.OK, "添加成功", orderId);
    }


    /***
     * 修改数据
     * @param order
     * @param id
     * @return
     */
    @PutMapping(value = "/{id}")
    public Result update(@RequestBody Order order, @PathVariable String id) {
        order.setId(id);
        orderService.update(order);
        return new Result(true, StatusCode.OK, "修改成功");
    }


    /***
     * 根据ID删除品牌数据
     * @param id
     * @return
     */
    @DeleteMapping(value = "/{id}")
    public Result delete(@PathVariable String id) {
        orderService.delete(id);
        return new Result(true, StatusCode.OK, "删除成功");
    }

    /***
     * 多条件搜索品牌数据
     * @param searchMap
     * @return
     */
    @GetMapping(value = "/search")
    public Result findList(@RequestParam Map searchMap) {
        List<Order> list = orderService.findList(searchMap);
        return new Result(true, StatusCode.OK, "查询成功", list);
    }


    /***
     * 分页搜索实现
     * @param searchMap
     * @param page
     * @param size
     * @return
     */
    @GetMapping(value = "/search/{page}/{size}")
    public Result findPage(@RequestParam Map searchMap, @PathVariable int page, @PathVariable int size) {
        Page<Order> pageList = orderService.findPage(searchMap, page, size);
        PageResult pageResult = new PageResult(pageList.getTotal(), pageList.getResult());
        return new Result(true, StatusCode.OK, "查询成功", pageResult);
    }

    @PostMapping("/batchSend")
    public Result batchSend(@RequestBody List<Order> orders) {
        orderService.batchSend(orders);
        return new Result(true, StatusCode.OK, "发货成功");
    }

    //查询echarts相关数据
    @RequestMapping("/findEchartsData")
    public Result<Integer>  findEchartsData(@RequestBody Map map){
        Integer result = orderService.findEchartsData(map);
        return new Result<>(true,StatusCode.OK,"查询成功",result);
    }


    /**
     * 查询待评论列表
     * @param pageNum
     * @return
     */
    @GetMapping("/evaluationPage")
    public Result<List<OrderResult>> evaluationPage(@RequestParam String pageNum){
        int parseInt;
        if(pageNum==null){
            parseInt=0;
        }
        parseInt = Integer.parseInt(pageNum);
        List<OrderResult> orderResultPage = orderService.evaluationPage(parseInt);
//        PageResult pageResult=new PageResult(orderResultPage.getTotal(),orderResultPage.getResult());
        return new Result(true,StatusCode.OK,"查询待评论成功",orderResultPage);
    }


    //查询物流信息

    @GetMapping("/getWuliuData")
    public Result<Map> getWuliuInfo(@RequestParam("orderId") String orderId){
        //这里的订单肯定是已经发货的
        //根据订单id 查询shipping_code（物流单号）
//        Order order = orderFeign.findById(orderId).getData();
//        String shippingCode = order.getShippingCode();
        //利用物流号查询物流信息
        String host = "https://wuliu.market.alicloudapi.com";
        String path = "/kdi";
        String method = "GET";
        System.out.println("请先替换成自己的AppCode");
        String appcode = "35ecc951a38140dcb678ab43f606c12e";  // !!!替换填写自己的AppCode 在买家中心查看
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Authorization", "APPCODE " + appcode); //格式为:Authorization:APPCODE 83359fd73fe11248385f570e3c139xxx
        Map<String, String> querys = new HashMap<String, String>();
        querys.put("no", " YT4387402518900 ");// !!! 请求参数
//        querys.put("type", "zto");// !!! 请求参数
        //JDK 1.8示例代码请在这里下载：  http://code.fegine.com/Tools.zip
        try {
            /**
             * 重要提示如下:
             * HttpUtils请从
             * https://github.com/aliyun/api-gateway-demo-sign-java/blob/master/src/main/java/com/aliyun/api/gateway/demo/util/HttpUtils.java
             * 或者直接下载：
             * http://code.fegine.com/HttpUtils.zip
             * 下载
             *
             * 相应的依赖请参照
             * https://github.com/aliyun/api-gateway-demo-sign-java/blob/master/pom.xml
             * 相关jar包（非pom）直接下载：
             * http://code.fegine.com/aliyun-jar.zip
             */
            HttpResponse response = HttpUtils.doGet(host, path, method, headers, querys);
            //System.out.println(response.toString());如不输出json, 请打开这行代码，打印调试头部状态码。
            //状态码: 200 正常；400 URL无效；401 appCode错误； 403 次数用完； 500 API网管错误
            //获取response的body
//            System.out.println(EntityUtils.toString(response.getEntity())); //输出json

            Map map = JSON.parseObject(EntityUtils.toString(response.getEntity()), Map.class);
            return new Result<Map>(true,StatusCode.OK,"查询成功",map);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }



    /*分页查询*/
    @RequestMapping("/findPage")
    public Result<PageResult> pageQurey(@RequestBody PageParam pageParam) {
        String currentPage = pageParam.getCurrentPage();
        String pageSize = pageParam.getPageSize();
        String receiverContactOrMobile = pageParam.getReceiverContactOrMobile();
        String id = pageParam.getId();
        String orderStatus = pageParam.getOrderStatus();
        String sourceType = pageParam.getSourceType();
        Map<String, Object> searchMap = new HashMap<>();
        if (receiverContactOrMobile != null && receiverContactOrMobile.length() > 0) {
            searchMap.put("receiverContact", receiverContactOrMobile);
            searchMap.put("receiverMobile", receiverContactOrMobile);
        }
        if (id != null && id.length() > 0) {
            searchMap.put("id", id);
        }
        if (orderStatus != null && orderStatus.length() > 0) {
            searchMap.put("orderStatus", orderStatus);
        }
        if (sourceType != null && sourceType.length() > 0) {
            searchMap.put("sourceType", sourceType);
        }

        Page<Order> orderPage = orderService.findPage(searchMap, Integer.parseInt(currentPage), Integer.parseInt(pageSize));
        long total = orderPage.getTotal();
        //封装返回结果
        PageResult pageResult = new PageResult();
        pageResult.setRows(orderPage);
        pageResult.setTotal(total);
        return new Result(true, StatusCode.OK, "查询成功", pageResult);
    }

}
