package com.changgou.order.dao;

import com.changgou.order.pojo.OrderLog;
import tk.mybatis.mapper.common.Mapper;

public interface OrderLogMapper extends Mapper<OrderLog> {

}
