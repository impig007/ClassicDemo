package com.changgou.pay.controller;

import com.alibaba.fastjson.JSON;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.internal.util.AlipaySignature;
import com.changgou.entity.Result;
import com.changgou.entity.StatusCode;
import com.changgou.pay.config.AlipayConfig;
import com.changgou.pay.config.RabbitMQConfig;
import com.changgou.pay.service.ALiPayService;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RequestMapping("/alipay")
@RestController
public class ALiPayController {

    @Autowired
    private AlipayConfig alipayConfig;

    @Autowired
    private ALiPayService aliPayService;

    @Autowired
    private RabbitTemplate rabbitTemplate;


    @GetMapping("/preCreatePay")
    public Result preCreatePay(@RequestParam("orderId") String orderId, @RequestParam("money")Integer money){
        Map resultMap = aliPayService.preCreatePay(orderId, money);
        return  new Result(true, StatusCode.OK,"",resultMap);
    }

    //支付宝回调
    @PostMapping("/alipayCallBack")
    public String alipayCallBack(HttpServletRequest request) {
        //获得支付宝传过来的参数
        Map<String, String[]> parameterMap = request.getParameterMap();//<String,String[]>
        String tradeStatus = request.getParameter("trade_status");
        System.out.println(JSON.toJSONString(parameterMap));

        Map<String, String> params = new HashMap();
        for (String key : parameterMap.keySet()) {
            params.put(key + "", request.getParameter(key + ""));
        }
        //进行验签 Map<String, String> params, String publicKey, String charset, String signType
        boolean rsa2 = false;
        try {
            params.remove("sign_type");
            rsa2 = AlipaySignature.rsaCheckV2(params, alipayConfig.getAlipayPublicKey(), "utf-8", "RSA2");
            if (rsa2 && "TRADE_SUCCESS".equals(tradeStatus)) {
                //订单支付成功，进行对应的订单工更新操作
                System.out.println("进行订单更新操作");

                //将订单的消息发送到mq
                Map message=new HashMap();
                message.put("orderId",params.get("out_trade_no"));//商家订单号
                message.put("transactionId",params.get("trade_no"));//支付宝交易号
                //发送消息
                rabbitTemplate.convertAndSend("", RabbitMQConfig.ORDER_PAY, JSON.toJSONString(message));
                //完成双向通信
                rabbitTemplate.convertAndSend("paynotify","",params.get("out_trade_no"));

            } else if (!rsa2) {
                return "非法操作，请立即停止违法犯罪！";
            }
            //响应》告知支付宝已接收到回调
            return "success";
        } catch (AlipayApiException e) {
            e.printStackTrace();
            return "非法操作，请立即停止违法犯罪！";
        }
    }

    //基于支付宝查询订单
    @GetMapping("/query/{orderId}")
    public Result queryOrder(@PathVariable("orderId") String orderId){
        Map map = aliPayService.query(orderId);
        return new Result(true,StatusCode.OK,"查询订单成功",map);
    }

    //基于支付宝关闭订单
    @PutMapping("/close/{orderId}")
    public Result closeOrder(@PathVariable("orderId") String orderId){
        Map map =aliPayService.close(orderId);
        return new Result(true,StatusCode.OK,"关闭订单成功",map);
    }

}
