package com.changgou.pay.service;

import java.util.Map;

public interface ALiPayService {
    Map preCreatePay(String orderId, Integer money);

    //基于支付宝查询订单
    Map query(String orderId);

    //基于支付宝关闭订单
    Map close(String orderId);
}

