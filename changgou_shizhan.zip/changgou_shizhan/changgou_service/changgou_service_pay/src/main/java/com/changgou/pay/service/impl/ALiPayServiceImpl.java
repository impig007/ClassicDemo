package com.changgou.pay.service.impl;

import com.alibaba.fastjson.JSON;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayTradeCloseRequest;
import com.alipay.api.request.AlipayTradePrecreateRequest;
import com.alipay.api.request.AlipayTradeQueryRequest;
import com.alipay.api.response.AlipayTradeCloseResponse;
import com.alipay.api.response.AlipayTradePrecreateResponse;
import com.alipay.api.response.AlipayTradeQueryResponse;
import com.changgou.pay.service.ALiPayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service
public class ALiPayServiceImpl implements ALiPayService {

    @Autowired
    private AlipayClient alipayClient;

    @Value("${alipay.notify_url}")
    private String notify_url;

    @Override
    public Map preCreatePay(String orderId, Integer money) {
        //1、创建一个用于调用接口的客户端对象

        //2、创建用户请求的对象
        AlipayTradePrecreateRequest request = new AlipayTradePrecreateRequest();

        //3、封装请求参数(支付宝)
        HashMap<String, String> params = new HashMap<>();
        params.put("out_trade_no", orderId);                   //out_trade_no必填：商户订单号
        params.put("product_code", "FAST_INSTANT_TRADE_PAY");
        /*product_code销售产品码。
        如果签约的是当面付快捷版，则传OFFLINE_PAYMENT;
        其它支付宝当面付产品传FACE_TO_FACE_PAYMENT；
        不传默认使用FACE_TO_FACE_PAYMENT；*/

        BigDecimal payMoney = new BigDecimal(money);//支付宝金额单位就是元
        params.put("total_amount", String.valueOf(payMoney));//total_amount必填: 订单总金额（单位元）


        params.put("subject", "土豪下单");//subject必填：订单标题
        request.setBizContent(JSON.toJSONString(params));
//        request.setReturnUrl("http://file.easy.echosite.cn/index_page.html");//支付成功跳转的页面
        request.setNotifyUrl(notify_url);
        //4、使用客户端对象发起支付预下单请求
        try {
            AlipayTradePrecreateResponse response = alipayClient.execute(request);
            //5、处理结果
            //当前订单编号
            System.out.println("支付订单编号：" + response.getOutTradeNo());
            //支付url
            System.out.println("支付url:" + response.getQrCode());

            System.out.println(response.getParams());//{biz_content={"out_trade_no":"商户订单号","total_amount":"订单总金额","subject":"畅购"}}

            return response.getParams();

        } catch (AlipayApiException e) {

            e.printStackTrace();

            return null;
        }

    }

    @Override
    public Map query(String orderId) {
        //1、创建一个用于调用接口的客户端对象

        //2、创建用户请求的对象
        AlipayTradeQueryRequest request = new AlipayTradeQueryRequest();
//       AlipayTradeCancelRequest request1 = new AlipayTradeCancelRequest();
        //3、封装请求参数
        HashMap<String, String> params = new HashMap<>();
        params.put("out_trade_no", orderId);
        request.setBizContent(JSON.toJSONString(params));
        //4、发起接口请求
        try {
            AlipayTradeQueryResponse response = alipayClient.execute(request);
            //处理请求结果
            //获取订单的交易状态
            //交易状态：WAIT_BUYER_PAY（交易创建，等待买家付款）、TRADE_CLOSED（未付款交易超时关闭，或支付完成后全额退款）、TRADE_SUCCESS（交易交易支付成功支付成功）、TRADE_FINISHED（交易结束，不可退款）
            String status = response.getTradeStatus();
            System.out.println("当前订单状态：" + status);

            return response.getParams();

        } catch (AlipayApiException e) {
            e.printStackTrace();
            return null;
        }

    }

    @Override
    public Map close(String orderId) {
        //1、创建一个用于调用接口的客户端对象

        //2、创建用户请求的对象
        AlipayTradeCloseRequest request = new AlipayTradeCloseRequest();

        //3、封装请求参数
        HashMap<String, String> params = new HashMap<>();
        params.put("out_trade_no", orderId);
        request.setBizContent(JSON.toJSONString(params));
        //4、发起接口请求
        try {
            AlipayTradeCloseResponse response = alipayClient.execute(request);
            //处理请求结果
            /*
            * <alipay_trade_close_response>
              <code>10000</code>        网关返回码
              <msg>Success</msg>        网关返回码描述
              <trade_no>2013112111001004500000675971</trade_no>    支付宝交易号
              <out_trade_no>YX_001</out_trade_no>                  创建交易传入的商户订单号
              </alipay_trade_close_response>
            *
            * */
            String outTradeNo = response.getOutTradeNo();
            System.out.println("创建交易传入的商户订单号：" + outTradeNo);

            return response.getParams();

        } catch (AlipayApiException e) {
            e.printStackTrace();
            return null;
        }

    }
}
