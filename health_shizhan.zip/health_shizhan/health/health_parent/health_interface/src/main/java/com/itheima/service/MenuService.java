package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.CheckItem;
import com.itheima.pojo.Menu;

import java.util.List;

public interface MenuService {
    List<CheckItem> findAll()throws Exception;

    PageResult findPage(QueryPageBean queryPageBean);

    List<Menu> getMenuList(String username)throws Exception;

    Menu findById(Integer id)throws Exception;

    void add(Menu menu)throws Exception;

    Result delById(Integer id)throws Exception;

    void edit(Menu menu)throws Exception;
}
