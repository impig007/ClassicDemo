package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.pojo.Sport;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface SportLibraryService {
    void upload(List<Sport> sports);
    void add(Sport sport);
    PageResult findPage(@RequestBody QueryPageBean queryPageBean);
}
