package com.itheima.service;

import com.itheima.pojo.Report;

import java.util.List;
import java.util.Map;

public interface ReportService {
    Report getBusinnessReport() throws Exception;

    /*获取每日预约、到诊数量统计*/
    Map getEverydayArriveExamine(Map map) throws Exception;

    /*获取体检收入统计*/
    List<Map> getSetmealStatistics(Map map) throws Exception;

    /*获取会员年份分布
     *   按0-6岁为婴幼儿、7-12岁为少儿、13-17岁为青少年、18-45岁为青年、46-69岁为中年、>69岁为老年
     * */
    List<Integer> getMemberAgeStatisticsReport();
}
