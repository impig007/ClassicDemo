package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.Result;
import com.itheima.pojo.AddOrderInputMessage;
import com.itheima.pojo.QueryConditionAndPageBean;
import com.itheima.pojo.StatuaAndId;

import java.util.List;
import java.util.Map;

public interface OrderService {
    public Result order(Map map) throws Exception;

    public Map findById(Integer id) throws Exception;

    PageResult findPageByOrderManage(QueryConditionAndPageBean queryPageBean);

    void add(AddOrderInputMessage addOrderInputMessage, Integer[] setmealIds) throws Exception;

    void delete(String id);

    void switchOrderStatus(StatuaAndId statuaAndId);

    void edit(Map map)throws Exception;


}
