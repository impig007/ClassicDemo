package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.pojo.Member;

import java.util.List;
import java.util.Map;

public interface MemberService {
    //根据手机号查询会员
    public Member findByTelephone(String telephone);
    public void add(Member member);
    public List<Integer> findMemberCountByMonths(List<String> months);

    PageResult findPage(QueryPageBean queryPageBean);

    void delete(Integer id);

    void edit(Member member);

    Member findById(Integer id);


    Member findByIds(Integer[] memberIds);
}
