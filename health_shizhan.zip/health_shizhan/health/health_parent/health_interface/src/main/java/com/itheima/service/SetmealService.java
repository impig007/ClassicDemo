package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.Result;
import com.itheima.pojo.Setmeal;

import java.util.List;
import java.util.Map;

public interface SetmealService {

    void add(Setmeal setmeal, Integer[] checkGroupIds);

    PageResult pageQuery(String queryString, Integer pageSize, Integer currentPage);

    List<Setmeal> findAll();

    Setmeal findById(int id);


    Result delById(Integer id)throws Exception;

    void updateById(Setmeal setmeal,Integer[] gids,String olderFileName)throws Exception;

    List<Integer> findsetMeal4Groups(Integer id)throws Exception;

    List<Map<String, Object>> findSetMealCount()throws Exception;
}
