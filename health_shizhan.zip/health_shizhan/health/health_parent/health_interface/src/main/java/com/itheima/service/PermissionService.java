package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.CheckItem;
import com.itheima.pojo.Permission;

import java.util.List;

public interface PermissionService {
    PageResult findPage(QueryPageBean queryPageBean);

    void add(Permission permission)throws Exception;

    void updateById(Permission permission)throws Exception;

    Permission findById(Integer id)throws Exception;

    Result delById(Integer id)throws Exception;

    List<CheckItem> findAll()throws Exception;
}
