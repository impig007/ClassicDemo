package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.Role;

import java.util.List;

public interface RoleService {
    List<Role> findAll()throws Exception;

    PageResult findPage(QueryPageBean queryPageBean);


    List<Integer> findPermissionIdsByRid(Integer rid)throws Exception;

    List<Integer> findMenuIdsByRid(Integer rid)throws Exception;

    void add(Role role, Integer[] permissionIds, Integer[] menuIds)throws Exception;

    void edit(Role role, Integer[] permissionIds, Integer[] menuIds)throws Exception;

    Result delById(Integer rid)throws Exception;

    Role findById(Integer rid)throws Exception;
}
