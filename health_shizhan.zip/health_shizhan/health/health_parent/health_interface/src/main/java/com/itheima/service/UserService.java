package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.User;

import java.util.List;

public interface UserService {
    public User findByUsername(String username);

    PageResult findPage(QueryPageBean queryPageBean);

    void add(User user,Integer[] roleIds)throws Exception;

    User findById(Integer uid)throws Exception;

    List<Integer> findRoleIdsByUid(Integer uid)throws Exception;

    void edit(User user, Integer[] roleIds)throws Exception;

    Result delById(Integer uid)throws Exception;

    User findByUser(String username);
}
