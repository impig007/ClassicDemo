package com.itheima.service;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.pojo.Dietary;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface DietaryLibraryService {
    void upload(List<Dietary> dietaries);
    void add(Dietary dietary);
    PageResult findPage(@RequestBody QueryPageBean queryPageBean);
}
