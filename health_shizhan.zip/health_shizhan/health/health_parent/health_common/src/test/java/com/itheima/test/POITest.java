package com.itheima.test;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class POITest {

    @Test
    public void test01() throws IOException {
        XSSFWorkbook xssfWorkbook = null;
        try {
            xssfWorkbook = new XSSFWorkbook(this.getClass().getResource("/hello.xlsx").getPath());
            XSSFSheet sheet = xssfWorkbook.getSheetAt(0);
            for (Row row : sheet) {
                for (Cell cell : row) {
                    System.out.println(cell.getStringCellValue());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (xssfWorkbook != null) {
                xssfWorkbook.close();
            }
        }
    }

    @Test
    public void test02() throws IOException {
        XSSFWorkbook xssfWorkbook = null;
        try {
            xssfWorkbook = new XSSFWorkbook(this.getClass().getResource("/hello.xlsx").getPath());
            XSSFSheet sheet = xssfWorkbook.getSheetAt(0);
            int lastRowNum = sheet.getLastRowNum();
            for (int i = 0; i <= lastRowNum; i++) {
                XSSFRow row = sheet.getRow(i);
                short lastCellNum = row.getLastCellNum();
                for (short j = 0; j < lastCellNum; j++) {
                    XSSFCell cell = row.getCell(j);
                    System.out.println(cell.getStringCellValue());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (xssfWorkbook != null) {
                xssfWorkbook.close();
            }
        }
    }

    @Test
    public void test03() throws IOException {
        XSSFWorkbook xssfWorkbook = new XSSFWorkbook();
        FileOutputStream fileOutputStream = null;
        try {
            XSSFSheet sheet = xssfWorkbook.createSheet("传智播客");

            XSSFRow row1 = sheet.createRow(0);
            row1.createCell(0).setCellValue("姓名");
            row1.createCell(1).setCellValue("成绩");
            row1.createCell(2).setCellValue("编号");

            XSSFRow row2 = sheet.createRow(1);
            row2.createCell(0).setCellValue("张三");
            row2.createCell(1).setCellValue("100");
            row2.createCell(2).setCellValue("N001");

            XSSFRow row3 = sheet.createRow(2);
            row3.createCell(0).setCellValue("李四");
            row3.createCell(1).setCellValue("99");
            row3.createCell(2).setCellValue("N002");


            String resourcePath = this.getClass().getResource("/").getPath();
            fileOutputStream = new FileOutputStream(resourcePath + "itcast.xlsx");
            xssfWorkbook.write(fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fileOutputStream != null) {
                fileOutputStream.flush();
                fileOutputStream.close();
            }
            xssfWorkbook.close();
        }
    }

}
