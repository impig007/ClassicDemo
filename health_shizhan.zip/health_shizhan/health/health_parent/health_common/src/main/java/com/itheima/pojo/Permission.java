package com.itheima.pojo;

import com.itheima.utils.DateUtils;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

/**
 * 权限
 */
public class Permission implements Serializable{
    private Integer id;
    private String name; // 权限名称
    private String keyword; // 权限关键字，用于权限控制
    private String description; // 描述
    private Date permissionDate;//权限的创建日期
    private String isEnable; //权限是否开启
    private String permissionDateStr;
    private Set<Role> roles = new HashSet<Role>(0);


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<Role> getRoles() {
        return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }

    public Date getPermissionDate() {
        return permissionDate;
    }

    public void setPermissionDate(Date permissionDate) throws Exception {
        String s = DateUtils.parseDate2String(permissionDate);
        this.permissionDateStr = s;
        this.permissionDate = permissionDate;
    }

    public String getIsEnable() {
        return isEnable;
    }

    public void setIsEnable(String isEnable) {
        this.isEnable = isEnable;
    }

    public String getPermissionDateStr() {
        return permissionDateStr;
    }

    public void setPermissionDateStr(String permissionDateStr) {
        this.permissionDateStr = permissionDateStr;
    }
}
