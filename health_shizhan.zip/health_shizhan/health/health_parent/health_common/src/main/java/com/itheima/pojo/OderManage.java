package com.itheima.pojo;

import java.io.Serializable;
/**
 *
 * @author stq
 * @description 封装前台预约数据
 **/


public class OderManage implements Serializable {
   private Integer id;
    private String memberName;
    private String memberPhoneNumber;
    private String orderDate;
    private String orderType;
    private String orderStatus;
    private Boolean orderStatus1;
    public Boolean getOrderStatus1() {
        return orderStatus1;
    }

    public void setOrderStatus1(Boolean orderStatus1) {
        this.orderStatus1 = orderStatus1;
    }


    private String setmealName;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberPhoneNumber() {
        return memberPhoneNumber;
    }

    public void setMemberPhoneNumber(String memberPhoneNumber) {
        this.memberPhoneNumber = memberPhoneNumber;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderStatus() {
        return  orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
     this.orderStatus=orderStatus;

    }

    public String getSetmealName() {
        return setmealName;
    }

    public void setSetmealName(String setmealName) {

        this.setmealName = setmealName;
    }


}
