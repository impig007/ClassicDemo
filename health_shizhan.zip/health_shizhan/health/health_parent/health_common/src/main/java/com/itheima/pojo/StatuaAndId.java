package com.itheima.pojo;

import java.io.Serializable;
/**
 *
 * @author stq
 * @description 封装一键改变预约状态参数
 **/


public class StatuaAndId  implements Serializable {
    private String status;
    private String status2;
    private String id;

    public String getStatus2() {
        return status2;
    }

    public void setStatus2(String status2) {
        this.status2 = status2;
    }



    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
