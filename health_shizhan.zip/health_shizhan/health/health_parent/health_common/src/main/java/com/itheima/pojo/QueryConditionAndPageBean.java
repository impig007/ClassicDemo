package com.itheima.pojo;

import java.io.Serializable;

/**
 *
 * @author stq
 * @description  封装查询条件数据
 **/


public class QueryConditionAndPageBean implements Serializable {

    private Integer currentPage;
    private Integer pageSize;
    private String selectPoneNumber;
    private String selectOrderType;
    private String selectOrderStatus;
    private String[] selectDate;

    //转换后的时间
    private String startDate;
    private String endDate;

    //转换状态
    private String selectOrderStatus2;

    public String getSelectOrderStatus2() {
        return selectOrderStatus2;
    }
    public void setSelectOrderStatus2(String selectOrderStatus2) {
        this.selectOrderStatus2 = selectOrderStatus2;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public Integer getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        this.currentPage = currentPage;
    }

    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public String getSelectPoneNumber() {
        return selectPoneNumber;
    }

    public void setSelectPoneNumber(String selectPoneNumber) {
        this.selectPoneNumber = selectPoneNumber;
    }

    public String getSelectOrderType() {
        return selectOrderType;
    }

    public void setSelectOrderType(String selectOrderType) {
        this.selectOrderType = selectOrderType;
    }

    public String getSelectOrderStatus() {
        return selectOrderStatus;
    }

    public void setSelectOrderStatus(String selectOrderStatus) {
        this.selectOrderStatus = selectOrderStatus;
    }

    public String[] getSelectDate() {
        return selectDate;
    }

    public void setSelectDate(String[] selectDate) {
        this.selectDate = selectDate;
    }





}
