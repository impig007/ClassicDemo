package com.itheima.pojo;

import java.io.Serializable;

/**
 * 套餐报表数据封装类
 */
public class SetmealOrder implements Serializable {
    private String name;
    private Integer value;
    private Integer setmeal_count;
    private Double proportion;

    public Integer getSetmeal_count() {
        return setmeal_count;
    }

    public void setSetmeal_count(Integer setmeal_count) {
        this.setmeal_count = setmeal_count;
    }

    public Double getProportion() {
        return proportion;
    }

    public void setProportion(Double proportion) {
        this.proportion = proportion;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }
}
