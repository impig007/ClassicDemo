package com.itheima.pojo;

import java.io.Serializable;

public class Dietary implements Serializable {
    private Integer id;
    private Integer parentId;
    private String name;
    private String code;
    private String tip;
    private String age;
    private String unit;
    private Integer unitBulk;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getTip() {
        return tip;
    }

    public void setTip(String tip) {
        this.tip = tip;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getUnitBulk() {
        return unitBulk;
    }

    public void setUnitBulk(Integer unitBulk) {
        this.unitBulk = unitBulk;
    }
}
