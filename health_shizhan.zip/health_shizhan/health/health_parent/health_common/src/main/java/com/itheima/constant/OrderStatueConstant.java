package com.itheima.constant;

public class OrderStatueConstant{
    public static final String ORDEROK="已到诊";
    public static final String ORDERNO="未到诊";
    public static final String ORDERSTYLE_WEIXIN="微信预约";
    public static final String ORDERSTYLE_PHONE="电话预约";
}
