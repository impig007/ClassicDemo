package com.itheima.pojo;

import java.io.Serializable;
/**
 *
 * @author stq
 * @description
 **/


public class AddOrderInputMessage implements Serializable {

    private String name;
    private String orderDate;
    private String phoneNumber;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
