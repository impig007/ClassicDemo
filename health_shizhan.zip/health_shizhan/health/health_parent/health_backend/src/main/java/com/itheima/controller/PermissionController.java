package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.CheckItem;
import com.itheima.pojo.Permission;
import com.itheima.service.PermissionService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/permission")
public class PermissionController {
    @Reference
    private PermissionService permissionService;
    //分页查询
    @RequestMapping("/findPage.do")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return permissionService.findPage(queryPageBean);
    }
    //新增权限
    @RequestMapping("/add")
    public Result add(@RequestBody Permission permission) {
        try {
            permissionService.add(permission);
            //执行成功
            return new Result(true, MessageConstant.ADD_PERMISSION_SUCCESS);
        } catch (Exception e) {
            //执行失败
            return new Result(false, MessageConstant.ADD_PERMISSION_FAIL);
        }
    }
    //修尴权限
    @RequestMapping("/updateById")
    public Result updateById(@RequestBody Permission permission) {
        try {
            permissionService.updateById(permission);
            //执行成功
            return new Result(true, MessageConstant.EDITE_PERMISSION_SUCCESS);
        } catch (Exception e) {
            //执行失败
            return new Result(false, MessageConstant.EDITE_PERMISSION_FAIL);
        }
    }
    //回显权限
    @RequestMapping("/findById")
    public Result findById(Integer id) {
        try {
            Permission permission = permissionService.findById(id);
            //查询成功
            return new Result(true, MessageConstant.QUERY_PERMISSION_SUCCESS , permission);

        } catch (Exception e) {
            //查询失败
            return new Result(false, MessageConstant.QUERY_PERMISSION_FAIL);
        }
    }

    @RequestMapping("/delById")
    public Result delById(Integer id) {
        Result result = null;
        try {
            result = permissionService.delById(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    @RequestMapping("/findAll")
    public Result findAll() {
        List<CheckItem> all = null;
        try {
            all = permissionService.findAll();
            return new Result(true, MessageConstant.QUERY_PERMISSION_SUCCESS, all);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.QUERY_PERMISSION_FAIL);
        }
    }

}
