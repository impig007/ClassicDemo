package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.Dietary;
import com.itheima.service.DietaryLibraryService;
import com.itheima.utils.POIUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/dietarylibrary")
public class DietaryLibraryController {
    @Reference
    private DietaryLibraryService dietaryLibraryService;

    @RequestMapping("/upload")
    public Result upload(@RequestParam("excelFile") MultipartFile file) {
        try {
            List<String[]> list = POIUtils.readExcel(file);
            if (list != null && list.size() > 0) {
                ArrayList<Dietary> dietaries = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    String[] strings = list.get(i);
                    Dietary dietary = new Dietary();
                    dietary.setParentId(Integer.valueOf(strings[1]));
                    dietary.setName(strings[2]);
                    dietary.setCode(strings[3]);
                    dietary.setTip(strings[4]);
                    dietary.setAge(strings[5]);
                    dietary.setUnit(strings[6]);
                    dietary.setUnitBulk(Integer.valueOf(strings[7]));
                    dietaries.add(dietary);
                }
                dietaryLibraryService.upload(dietaries);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.IMPORT_DIETARIES_FAIL);
        }

        return new Result(true, MessageConstant.IMPORT_DIETARIES_SUCCESS);
    }

    @RequestMapping("/add.do")
    public Result add(@RequestBody Dietary dietary) {
        try {
            dietaryLibraryService.add(dietary);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.IMPORT_DIETARY_FAIL);
        }
        return new Result(true, MessageConstant.IMPORT_DIETARY_SUCCESS);
    }

    @RequestMapping("/findPage.do")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return dietaryLibraryService.findPage(queryPageBean);
    }
}
