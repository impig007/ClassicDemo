package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.Result;
import com.itheima.pojo.User;
import com.itheima.service.UserService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/personal")
public class PersonalController {
    @Reference
    private UserService userService;


    @RequestMapping("/findAll")
    public Result findAll( String username){
        try {
           User user =  userService.findByUser(username);
            List<User> users = new ArrayList<>();
            users.add(user);
            return new Result(true, MessageConstant.QUERY_USER_SUCCESS,users);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.QUERY_USER_FAIL);
        }
    }
}
