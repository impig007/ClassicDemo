package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.Sport;
import com.itheima.service.SportLibraryService;
import com.itheima.utils.POIUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/sportlibrary")
public class SportLibraryController {
    @Reference
    private SportLibraryService sportLibraryService;

    @RequestMapping("/upload")
    public Result upload(@RequestParam("excelFile") MultipartFile file) {
        try {
            List<String[]> list = POIUtils.readExcel(file);
            if (list != null && list.size() > 0) {
                ArrayList<Sport> sports = new ArrayList<>();
                for (int i = 0; i < list.size(); i++) {
                    String[] strings = list.get(i);
                    Sport sport = new Sport();
                    sport.setCode(strings[1]);
                    sport.setName(strings[2]);
                    sport.setKind(Integer.valueOf(strings[3]));
                    sport.setTime(strings[4]);
                    sport.setFrequency(strings[5]);
                    sport.setAge(strings[6]);
                    sport.setMethod(strings[7]);
                    sports.add(sport);
                }
                sportLibraryService.upload(sports);
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.IMPORT_SPORTS_FAIL);
        }

        return new Result(true, MessageConstant.IMPORT_SPORTS_SUCCESS);
    }

    @RequestMapping("/add.do")
    public Result add(@RequestBody Sport sport) {
        try {
            sportLibraryService.add(sport);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.IMPORT_SPORT_FAIL);
        }
        return new Result(true, MessageConstant.IMPORT_SPORT_SUCCESS);
    }

    @RequestMapping("/findPage.do")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return sportLibraryService.findPage(queryPageBean);
    }
}
