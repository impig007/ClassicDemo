package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.CheckGroup;
import com.itheima.pojo.Order;
import com.itheima.service.CheckGroupService;
import com.itheima.service.OrderService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/order")
public class OrderController {
    @Reference
    private OrderService orderService;

    @RequestMapping("/edit")
    public Result edit(@RequestBody Map map) {
        try {
            orderService.edit(map);
            return new Result(true, "预约编辑成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "预约编辑失败");

        }
    }
}
