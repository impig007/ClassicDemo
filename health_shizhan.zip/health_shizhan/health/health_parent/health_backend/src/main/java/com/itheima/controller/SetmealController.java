package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.constant.RedisConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.Setmeal;
import com.itheima.service.SetmealService;
import com.itheima.utils.QiniuUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import redis.clients.jedis.JedisPool;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/setmeal")
public class SetmealController {

    @Reference
    private SetmealService setmealService;

    @RequestMapping("/add")
    public Result add(@RequestBody Setmeal setmeal, Integer[] checkgroupIds) {
        try {
            setmealService.add(setmeal, checkgroupIds);
            return new Result(true, MessageConstant.ADD_SETMEAL_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.ADD_SETMEAL_FAIL);
        }
    }

    @Autowired
    private JedisPool jedisPool;


    @RequestMapping("/upload")
    public Result upload(@RequestParam("imgFile") MultipartFile multipartFile) {
        try {
            String originalFilename = multipartFile.getOriginalFilename();//获取原始文件名  新建套餐.png
            int lastIndexOf = originalFilename.lastIndexOf("."); //获取后缀

            String suffix = originalFilename.substring(lastIndexOf - 1);
            String fileName = UUID.randomUUID().toString() + suffix;
            QiniuUtils.upload2Qiniu(multipartFile.getBytes(), fileName);
            jedisPool.getResource().sadd(RedisConstant.SETMEAL_PIC_RESOURCES, fileName);
            return new Result(true, MessageConstant.PIC_UPLOAD_SUCCESS, fileName);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.PIC_UPLOAD_FAIL);
        }
    }

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return setmealService.pageQuery(queryPageBean.getQueryString(), queryPageBean.getPageSize(), queryPageBean.getCurrentPage());
    }


    //--------基本功能完善----------
    @PreAuthorize("hasAuthority('SETMEAL_DELETE')")
    @RequestMapping("/delById")
    public Result delById(Integer id){
        Result result =null;
        try {
            //执行成功
            result= setmealService.delById(id);
        } catch (Exception e) {
            //执行失败
            e.printStackTrace();
        }
        return result;
    }
    @PreAuthorize("hasAuthority('SETMEAL_EDIT')")
    @RequestMapping("/updateById")
    public Result updateById(@RequestBody Setmeal setmeal,Integer[] checkgroupIds,String oldeFileName){
        try {
            setmealService.updateById(setmeal,checkgroupIds,oldeFileName);
            //执行成功
            return  new Result(true, MessageConstant.UPDATE_SETMEAL_SUCCESS);
        } catch (Exception e) {
            //执行失败
            return  new Result(false, MessageConstant.UPDATE_SETMEAL_FAIL);
        }
    }
    @RequestMapping("/findById")
    public Result findById(Integer id){
        try {
            Setmeal setmeal = setmealService.findById(id);
            //查询成功
            return  new Result(true,MessageConstant.QUERY_CHECKGROUP_SUCCESS,setmeal);

        } catch (Exception e) {
            //查询失败
            return new Result(false,MessageConstant.QUERY_CHECKGROUP_FAIL);
        }
    }

    @RequestMapping("/findsetMeal4Groups")
    public List<Integer> findsetMeal4Groups(Integer id){
        try {
            return setmealService.findsetMeal4Groups(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}
