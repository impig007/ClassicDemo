package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;

import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.CheckGroup;
import com.itheima.pojo.CheckItem;

import com.itheima.pojo.Role;
import com.itheima.service.RoleService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/role")
public class RoleController {
    @Reference
    private RoleService roleService;

    @RequestMapping("/findAll")
    public Result findAll() {
        List<Role> all = null;
        try {
            all = roleService.findAll();
            if (all != null && all.size() != 0) {
                return new Result(true, MessageConstant.QUERY_ROLE_SUCCESS, all);
            }
            return new Result(false, MessageConstant.QUERY_ROLE_FAIL);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.QUERY_ROLE_FAIL);
        }

    }

    @RequestMapping("/findPage")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return roleService.findPage(queryPageBean);
    }

    @RequestMapping("/findPermissionIdsByRid")
    public Result findPermissionIdsByRid(Integer rid) {
        try {
            List<Integer> roleIds = roleService.findPermissionIdsByRid(rid);
            return new Result(true,MessageConstant.QUERY_PERMISSION_SUCCESS,roleIds);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.QUERY_PERMISSION_FAIL);
        }
    }

    @RequestMapping("/findMenuIdsByRid")
    public Result findMenuIdsByRid(Integer rid) {
        try {
            List<Integer> menuIds = roleService.findMenuIdsByRid(rid);
            return new Result(true,MessageConstant.GET_MENU_SUCCESS,menuIds);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.GET_MENU_FAIL);
        }
    }

    @RequestMapping("/add")
    public Result add(@RequestBody Role role, Integer[] permissionIds, Integer[] menuIds) {
        try {
            roleService.add(role, permissionIds,menuIds);
            return new Result(true, MessageConstant.ADD_CHECKGROUP_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.ADD_CHECKGROUP_FAIL);
        }
    }

    @RequestMapping("/edit")
    public Result edit(@RequestBody  Role role, Integer[] permissionIds, Integer[] menuIds) {
        try {
            roleService.edit(role, permissionIds,menuIds);
            return new Result(true, MessageConstant.EDIT_CHECKGROUP_SUCCESS);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.EDIT_CHECKGROUP_FAIL);
        }
    }
    @RequestMapping("/delById")
    public Result delById(Integer rid)  {
        Result result =null;
        try {
            result = roleService.delById(rid);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    @RequestMapping("/findById")
    public Result findById(Integer rid) {
        try {
            Role role= roleService.findById(rid);
            return new Result(true, MessageConstant.QUERY_ROLE_SUCCESS, role);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.QUERY_ROLE_FAIL);
        }
    }

}
