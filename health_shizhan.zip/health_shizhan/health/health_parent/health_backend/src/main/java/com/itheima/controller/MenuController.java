package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.QueryPageBean;
import com.itheima.entity.Result;
import com.itheima.pojo.CheckGroup;
import com.itheima.pojo.CheckItem;
import com.itheima.pojo.Menu;
import com.itheima.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/menu")
public class MenuController {
    @Reference
    private MenuService menuService;
    @RequestMapping("/findAll")
    public Result findAll() {
        List<CheckItem> all = null;
        try {
            all = menuService.findAll();
            return new Result(true, MessageConstant.QUERY_PERMISSION_SUCCESS, all);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, MessageConstant.QUERY_PERMISSION_FAIL);
        }
    }

    @RequestMapping("/findPage.do")
    public PageResult findPage(@RequestBody QueryPageBean queryPageBean) {
        return menuService.findPage(queryPageBean);
    }

    @RequestMapping("/getMenuList")
    public Result getMenuList(String username){
        try {
            List<Menu> lists=menuService.getMenuList(username);
            return new Result(true,"菜单数据加载成功!",lists);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false,"菜单数据加载失败!");
        }
    }

    @RequestMapping("/findById")
    public Result findById(Integer id){
        try {
            Menu menu=menuService.findById(id);
            return new Result(true,"查询菜单成功！",menu);
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false,"查询菜单成功!");
        }
    }

    @RequestMapping("/add")
    public Result add(@RequestBody Menu menu) {
        try {
            Integer parentMenuId = menu.getParentMenuId();
            if (parentMenuId==0){
                menu.setParentMenuId(null);
            }
            menuService.add(menu);
            return new Result(true, "新增菜单成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "新增失败");
        }
    }

    @RequestMapping("/delById")
    public Result delById(Integer id)  {
        Result result =null;
        try {
            result = menuService.delById(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    @RequestMapping("/edit")
    public Result edit(@RequestBody Menu menu) {
        try {
            menuService.edit(menu);
            return new Result(true, "修改成功");
        } catch (Exception e) {
            e.printStackTrace();
            return new Result(false, "修改成功");
        }
    }
}
