package com.itheima.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.itheima.constant.MessageConstant;
import com.itheima.entity.PageResult;
import com.itheima.entity.Result;
import com.itheima.pojo.*;
import com.itheima.service.OrderService;
import com.itheima.service.SetmealService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import java.util.*;
/**
 *
 * @author stq
 * @description   查询预约订单分页
 **/
@RestController
@RequestMapping("/ordermanger")
public class OrderManageController {
    @Reference
    private OrderService orderService;
    @Reference
    private SetmealService setmealService;
    /**
     *
     * @author stq
     * @description 一键改变状态
     **/
     @RequestMapping("/switchOrderStatus")
     public  Result switchOrderStatus(@RequestBody StatuaAndId statuaAndId ){
         try {
             if (statuaAndId!=null){
                 System.out.println(statuaAndId.getStatus());
                 //点击按钮后的状态
                 if (statuaAndId.getStatus().equals("true")){

                     statuaAndId.setStatus2(Order.ORDERSTATUS_YES);
                 }
                 if (statuaAndId.getStatus().equals("false")){

                     statuaAndId.setStatus2(Order.ORDERSTATUS_NO);
                 }
             orderService.switchOrderStatus(statuaAndId);
             }
             return new Result(true,MessageConstant.SWITCH_STATUS_SUCCESS);
         } catch (Exception e) {
             e.printStackTrace();
             return new Result(false,MessageConstant.SWITCH_STATUS_FAIL);
         }
     }
/**
 *
 * @author stq
 * @description 删除电话预约信息
 **/
 @RequestMapping("/delete")
 public Result delete(String id){
     try {
         orderService.delete(id);
         return new Result(true,MessageConstant.DELETE_ORDERBYPHONE_SUCCESS);
     } catch (Exception e) {
         e.printStackTrace();
         return new Result(false,MessageConstant.DELETE_ORDERBYPHONE_FAIL);
     }

 }
    /**
     *
     * @author stq
     * @description 添加预约信息
     **/
@RequestMapping("add")
public  Result add(@RequestBody AddOrderInputMessage addOrderInputMessage,Integer[] setmealIds){

    try {
        orderService.add(addOrderInputMessage,setmealIds);
        return new Result(true,MessageConstant.ADD_ORDER_SUCCESS);
    } catch (Exception e) {
        e.printStackTrace();
        return new Result(false,MessageConstant.ADD_ORDER_FAIL);
    }
}

/**
 *
 * @author stq
 * @description 查询order菜单
 **/
    @RequestMapping("/findAll")
    public Result findAll() {
        try {
            List<Setmeal> all = setmealService.findAll();
            return new Result(true,MessageConstant.QUERY_SETMEAL_SUCCESS,all);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return  new Result(false,MessageConstant.QUERY_SETMEAL_FAIL);
    }

/**
 *
 * @author stq
 * @description 查询预约订单分页并根据条件查询
 **/
        @RequestMapping("/findPageByOrderManage")
        public PageResult findPageByOrderManage(@RequestBody QueryConditionAndPageBean queryPageBean1) {
         PageResult pageResult=null;

            try {
                if (queryPageBean1 != null) {
                    pageResult = orderService.findPageByOrderManage(queryPageBean1);
                    List<OderManage> list = pageResult.getRows();
                    for (OderManage manage : list) {
                        if (manage != null) {
                            if (manage.getOrderStatus().equals("未到诊")) {
                                manage.setOrderStatus1(false);
                            }
                            if (manage.getOrderStatus().equals("已到诊")) {
                                manage.setOrderStatus1(true);
                            }

                        }
                    }

                }
                return pageResult;
            } catch (Exception e) {
                e.printStackTrace();
                return pageResult;
            }

        }

}
