package com.itheima.service.impl;

import com.itheima.domain.Department;
import com.itheima.mapper.DepartmentMapper;
import com.itheima.service.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {
    @Autowired
    private DepartmentMapper departmentMapper;
    @Override
    public List<Department> findAll() throws Exception {

        return departmentMapper.findAll();
    }
}
