package com.itheima.service;

import com.itheima.domain.Patients;

import java.util.List;

public interface PatientsService {
    List<Patients> findAll() throws Exception;

    void savePatients(Patients patients)throws Exception;
}
