package com.itheima.service.impl;

import com.itheima.domain.Patients;
import com.itheima.mapper.PatientsMapper;
import com.itheima.service.PatientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PatientsServiceImpl implements PatientsService {
    @Autowired
    private PatientsMapper patientsMapper;
    @Override
    public List<Patients> findAll() throws Exception {

        return patientsMapper.findAll();
    }

    @Override
    public void savePatients(Patients patients) throws Exception {
        System.out.println(patients);
        if (patients!=null){
            patientsMapper.save(patients);
        }
    }
}
