package com.itheima.domain;

import java.io.Serializable;

public class Patients implements Serializable {
    private int id;
    private String name;
    private int gender;
    private String genderStr;
    private int did;
    private String advice;
    private Department department;

    public String getGenderStr() {
        if (gender==1){
            this.genderStr="男";
        }
        if (gender==0){
            this.genderStr="女";
        }
        return genderStr;
    }

    public void setGenderStr(String genderStr) {
        this.genderStr = genderStr;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getGender() {

        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public String getAdvice() {
        return advice;
    }

    public void setAdvice(String advice) {
        this.advice = advice;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return "Patients{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", gender=" + gender +
                ", did=" + did +
                ", advice='" + advice + '\'' +
                ", department=" + department +
                '}';
    }
}
