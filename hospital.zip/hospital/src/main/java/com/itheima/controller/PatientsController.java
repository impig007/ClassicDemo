package com.itheima.controller;

import com.itheima.domain.Patients;
import com.itheima.service.PatientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Controller
@RequestMapping("/patients")
public class PatientsController {

    @Autowired
    private PatientsService patientsService;

    @RequestMapping("/findAll")
    public String findAll(Model model)throws Exception{
       List<Patients> patientsList =  patientsService.findAll();
       model.addAttribute("patientsList",patientsList);
        return "patients-list";
    }
    @RequestMapping("/savePatients")
    public String savePatients(Patients patients)throws Exception{
        patientsService.savePatients(patients);
        return "patients-list";
    }
}
