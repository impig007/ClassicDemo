package com.itheima.controller;

import com.itheima.domain.Department;
import com.itheima.domain.Patients;
import com.itheima.service.DepartmentService;
import com.itheima.service.PatientsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller
@RequestMapping("/department")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;
    @ResponseBody
    @RequestMapping("/findAll")
    public List<Department> findAll()throws Exception{
        List<Department> departmentList = departmentService.findAll();
        return departmentList;
    }

}
