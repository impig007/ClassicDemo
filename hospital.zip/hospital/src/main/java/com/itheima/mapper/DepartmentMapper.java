package com.itheima.mapper;

import com.itheima.domain.Department;
import org.springframework.stereotype.Service;

import java.util.List;


public interface DepartmentMapper {

    List<Department> findAll()throws Exception;
}
