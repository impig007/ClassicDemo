package com.itheima.mapper;

import com.itheima.domain.Patients;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface PatientsMapper {
    List<Patients> findAll()throws Exception;

    void save(Patients patients)throws Exception;
}
