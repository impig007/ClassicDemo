package com.itheima.intercept;

import com.itheima.domain.User;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//登陆拦截器，实现判断用户是否登陆从而进行下一步访问的功能
public class LoginIntercept implements HandlerInterceptor{
    //在执行处理器之前拦截
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        User user = (User) request.getSession().getAttribute("user");
        if (user==null){
            //域中没有数据，说明没有登陆成功过，重定向到登陆界面
            response.sendRedirect(request.getContextPath()+"/pages/login.jsp");
            return false;
        }
        return true;
    }
}