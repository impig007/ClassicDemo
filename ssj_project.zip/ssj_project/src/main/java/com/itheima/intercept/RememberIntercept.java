package com.itheima.intercept;

import com.itheima.domain.User;
import com.itheima.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class RememberIntercept implements HandlerInterceptor {
    @Autowired
    private UserService userService;
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        //先判断session域中user是否为空（是否验证通过）
        Object user = request.getSession().getAttribute("user");
        if (user!=null){
            //登陆成功,放行
            return true;
        }
        //验证不通过，先拿到指定cookie
        Cookie[] cookies = request.getCookies();
        Cookie autoLoginCookie = getCookieByName(cookies, "autoLoginCookie");
        //判断cookie，如果为空(说明没有登陆成功过)则放行让他去其他过滤器继续完成登陆
        if (autoLoginCookie==null){
            return true;
        }
        //如果cookie不为空，先拿到值判断一下能不能取到user，如果能说明这个cookie是合法的，持久化存储，否则是非法的，放行
        String value = autoLoginCookie.getValue();
        //将value值分别获取用户名和密码
        String username = value.split("@")[0];
        String password = value.split("@")[1];
        //调用service中的方法查询的到user

        User user_c = userService.login(username, password);
        if (user_c==null){
            //说明这个cookie是假的,放行，让他继续去登陆
            return true;
        }
        // 说明存在有效cookie，将user存入session域，这样登陆过滤器就不会拦你了，意思你可以自动登陆了
        request.getSession().setAttribute("user",user_c);
        return true;
    }

    private Cookie getCookieByName(Cookie[] cookies, String cookieName) {
        if(cookies!=null){
            for (Cookie cookie : cookies) {
                if(cookieName.equals(cookie.getName())){
                    //找到指定cookie
                    return cookie;
                }
            }
        }
        return null;
    }
}
