package com.itheima.exception;

public class MyException extends RuntimeException {

}
