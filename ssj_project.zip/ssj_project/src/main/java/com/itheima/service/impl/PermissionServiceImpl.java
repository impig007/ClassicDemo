package com.itheima.service.impl;

import com.itheima.dao.PermissionDao;
import com.itheima.domain.Permission;
import com.itheima.domain.Role;
import com.itheima.service.PermissionService;
import com.itheima.utils.Uuid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermissionServiceImpl implements PermissionService {
    @Autowired
    private PermissionDao permissionDao;
    @Override
    public List<Permission> findAll() throws Exception {

        return permissionDao.findAll();
    }

    @Override
    public void save(Permission permission) throws Exception {
        permission.setId(Uuid.getId());
        permissionDao.save(permission);
    }

    @Override
    public Permission findPermissionById(String pid) throws Exception {
        //根据pid查找到权限
        Permission permission = permissionDao.findPermissionById(pid);
        //根据pid查找到权限对应的roles
        List<Role> roleList = permissionDao.findPermissionRoles(pid);
        permission.setRoles(roleList);
        return permission;
    }

    @Override
    public void deleteBySelected(String _pids) throws Exception {
        //处理uids为数组格式
        String[] pids = _pids.split(",");
        if (pids!=null&&pids.length>0){
            for (String pid : pids) {
                //首先删除role-user中的uid相关数据
                permissionDao.deletePermissonRoles(pid);
                //删除自身表中的数据
                permissionDao.deletePermissionById(pid);
            }
        }
    }
}
