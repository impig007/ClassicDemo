package com.itheima.service.impl;

import com.itheima.dao.RoleDao;
import com.itheima.dao.UserDao;
import com.itheima.domain.Role;
import com.itheima.domain.User;
import com.itheima.service.UserService;
import com.itheima.utils.Uuid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;
    @Autowired
    RoleDao roleDao;

    @Override
    public List<User> findAll() throws Exception {
        //便利集合
        return userDao.findAll();
    }

    @Override
    public void save(User user) throws Exception {
        user.setId(Uuid.getId());
        userDao.save(user);
    }

    @Override
    public List<Role> findUserRoles(String uid) throws Exception {

        return userDao.findUserRoles(uid);
    }

    @Override
    public void updateUserRoles(String userId, String[] ids) throws Exception {
        //为了防止ids为空或者null加一层判断
        if (ids!=null&&ids.length>0 ){
            //在增加之前，为防止重复添加，应将uid对应的角色全部删除再添加
            userDao.deleteUserRoles(userId);
            //遍历ids，调用userdao中方法增加
            for (String roleId : ids) {
                userDao.addUserRole(userId,roleId);
            }
        }

    }

    @Override
    public void deleteBySelected(String _uids) throws Exception {
        //处理uids为数组格式
        String[] uids = _uids.split(",");
        if (uids!=null&&uids.length>0){
            for (String uid : uids) {
                //首先删除role-user中的uid相关数据
                userDao.deleteUserRoles(uid);
                //删除自身表中的数据
                userDao.deleteUserById(uid);
            }
        }
    }

    @Override
    public User findUserById(String uid) throws Exception {
        //根据id查找到用户
        User user = userDao.findUserById(uid);
        //根据id查找到用户对应的roles
        List<Role> roleList = userDao.findUserRoles(uid);
        user.setRoles(roleList);
        return user;
    }

    @Override
    public User login(String username, String password) throws Exception {
        User user = userDao.finUserByUsernamePwd(username,password);
        return user;
    }
}
