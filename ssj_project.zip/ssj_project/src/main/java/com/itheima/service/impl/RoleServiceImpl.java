package com.itheima.service.impl;

import com.itheima.dao.RoleDao;
import com.itheima.domain.Permission;
import com.itheima.domain.Role;
import com.itheima.service.RoleService;
import com.itheima.utils.Uuid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {
    @Autowired
    private RoleDao roleDao;
    @Override
    public List<Role> findAllRole() throws Exception {
        return roleDao.findAllRole();

    }

    @Override
    public void save(Role role) throws Exception {
        role.setId(Uuid.getId());
        roleDao.save(role);
    }

    @Override
    public Role findRoleById(String rid) throws Exception {
        //根据rid查找到role
        Role role = roleDao.findRoleById(rid);
        //根据rid查找到用户对应的permission
        List<Permission> permissionList= roleDao.findRolePermissions(rid);
        role.setPermissions(permissionList);
        return role;
    }

    @Override
    public void deleteRoleById(String rid) throws Exception {
        //删除角色，删除user_role 表(根据rid deleteRoleUsers)和
        roleDao.deleteRoleUsers(rid);
        // role_permission(根据rid   deleteRolePermissions)对应的数据(根据)
        roleDao.deleteRolePermissions(rid);
        //删除自身表中role数据
        roleDao.deleteById(rid);
    }
    //获取用户对应的权限s
    @Override
    public List<Permission> findRolePermissions(String rid) throws Exception {
        return roleDao.findRolePermissions(rid);
    }

    @Override
    public void updateRolePermissions(String roleId, String[] ids) throws Exception {
        //为了防止ids为空或者null加一层判断
        if (ids!=null&&ids.length>0 ){
            //在增加之前，为防止重复添加，应将rid对应的角色全部删除再添加
            roleDao.deleteRolePermissions(roleId);
            //遍历ids，调用userdao中方法增加
            for (String pid : ids) {
                roleDao.addRolePermission(roleId,pid);
            }
        }
    }
}
