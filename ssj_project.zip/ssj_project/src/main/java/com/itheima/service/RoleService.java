package com.itheima.service;

import com.itheima.domain.Permission;
import com.itheima.domain.Role;

import java.util.List;

public interface RoleService {

    List<Role> findAllRole() throws Exception;

    void save(Role role)throws Exception;

    Role findRoleById(String rid)throws Exception;

    void deleteRoleById(String rid) throws Exception;

    List<Permission> findRolePermissions(String rid)throws Exception;

    void updateRolePermissions(String roleId, String[] ids)throws Exception;
}
