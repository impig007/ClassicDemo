package com.itheima.service;

import com.itheima.domain.Role;
import com.itheima.domain.User;

import java.util.List;

public interface UserService {
    List<User> findAll() throws Exception;

    void save(User user) throws Exception;

    List<Role> findUserRoles(String uid)throws Exception;

    void updateUserRoles(String userId, String[] ids) throws Exception;

    void deleteBySelected(String uids)throws Exception;

    User findUserById(String uid)throws Exception;

    User login(String username, String password)throws Exception;
}
