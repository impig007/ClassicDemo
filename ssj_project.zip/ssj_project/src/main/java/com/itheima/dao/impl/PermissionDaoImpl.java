package com.itheima.dao.impl;

import com.itheima.dao.PermissionDao;
import com.itheima.domain.Permission;
import com.itheima.domain.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class PermissionDaoImpl implements PermissionDao {
    @Autowired
    private JdbcTemplate template;
    @Override
    public List<Permission> findAll() throws Exception {
        String sql = "select * from permission";
        return template.query(sql,new BeanPropertyRowMapper<Permission>(Permission.class));
    }

    @Override
    public void save(Permission permission) throws Exception {
        String sql = "insert into permission values (?,?,?)";
        template.update(sql,permission.getId(),permission.getPermissionName(),permission.getUrl());
    }

    @Override
    public Permission findPermissionById(String pid) throws Exception {
        Permission permission= null;
        try {
            String sql = "select * from permission where id=?";
            permission = template.queryForObject(sql,new BeanPropertyRowMapper<Permission>(Permission.class),pid);
        }catch (Exception e){

        }
        return permission;
    }

    @Override
    public List<Role> findPermissionRoles(String pid) throws Exception {
        String sql = "select * from role where id in(select roleId  FROM role_permission where permissionId=?)";
        List<Role> roleList = template.query(sql, new BeanPropertyRowMapper<Role>(Role.class), pid);
        return roleList;
    }
    //删除权限对应的roles
    @Override
    public void deletePermissonRoles(String pid) throws Exception {
        String sql="delete from role_permission where permissionid=?";
        template.update(sql,pid);
    }
    //删除权限表中id对应的一条
    @Override
    public void deletePermissionById(String pid) throws Exception {
        String sql="delete from permission where id=?";
        template.update(sql,pid);
    }
}
