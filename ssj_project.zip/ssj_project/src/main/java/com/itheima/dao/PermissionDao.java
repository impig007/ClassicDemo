package com.itheima.dao;

import com.itheima.domain.Permission;
import com.itheima.domain.Role;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PermissionDao {
    List<Permission> findAll()throws Exception;

    void save(Permission permission)throws Exception;

    Permission findPermissionById(String pid)throws Exception;

    List<Role> findPermissionRoles(String pid)throws Exception;

    void deletePermissonRoles(String pid)throws Exception;

    void deletePermissionById(String pid)throws Exception;
}
