package com.itheima.dao.impl;

import com.itheima.dao.UserDao;
import com.itheima.domain.Role;
import com.itheima.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public class UserDaoImpl implements UserDao {
    @Autowired
    private JdbcTemplate template;
    @Override
    public List<User> findAll() throws Exception {
        return template.query("select * from users",new BeanPropertyRowMapper<User>(User.class));
    }

    @Override
    public void save(User user) throws Exception {
        template.update("insert into users values (?,?,?,?,?,?)",user.getId(),user.getEmail(),user.getUsername(),user.getPassword(),user.getPhoneNum(),user.getStatus());
    }

    @Override
    public List<Role> findUserRoles(String uid) throws Exception {
        String sql = "select * from role where id in(select roleId  FROM users_role where userid=?)";
        return template.query(sql,new BeanPropertyRowMapper<Role>(Role.class),uid);
    }

    @Override
    public void addUserRole(String userId, String roleId) throws Exception {
        String sql = "insert into  users_role values (?,?)";
        template.update(sql,userId,roleId);
    }

    @Override
    public void deleteUserRoles(String userId) throws Exception {
        String sql="delete from users_role where userid=?";
        template.update(sql,userId);
    }

    @Override
    public void deleteUserById(String uid) throws Exception {
        String sql="delete from users where id=?";
        template.update(sql,uid);
    }

    @Override
    public User findUserById(String uid) throws Exception {
        User user = null;
        try {

            String sql="select * from users where id=?";
            user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), uid);
        }catch (Exception e){}
        return user;
    }

    @Override
    public User finUserByUsernamePwd(String username, String password) throws Exception {
        String sql="select * from users where username=? and password=?";
        User user = null;
        try {
            user = template.queryForObject(sql, new BeanPropertyRowMapper<User>(User.class), username,password);
        }catch (Exception e){}
        return user;
    }
}
