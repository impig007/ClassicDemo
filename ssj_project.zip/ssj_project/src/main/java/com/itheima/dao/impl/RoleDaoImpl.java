package com.itheima.dao.impl;

import com.itheima.dao.RoleDao;
import com.itheima.domain.Permission;
import com.itheima.domain.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class RoleDaoImpl implements RoleDao {
    @Autowired
    private JdbcTemplate template;
    //获取所有的角色集合
    @Override
    public List<Role> findAllRole() throws Exception {
        return template.query("select * from role",new BeanPropertyRowMapper<Role>(Role.class));
    }
    //保存单个角色
    @Override
    public void save(Role role) throws Exception {
        template.update("insert into role values (?,?,?)",role.getId(),role.getRoleName(),role.getRoleDesc());
    }

    @Override
    public Role findRoleById(String rid) {
        Role role = null;
        try {
            role = template.queryForObject("select * from role where id=?",new BeanPropertyRowMapper<Role>(Role.class),rid);
        }catch (Exception e){

        }
        return role;
    }

    @Override
    public void deleteRoleUsers(String rid) throws Exception {
        String sql="delete from users_role where roleid=?";
        template.update(sql,rid);
    }

    @Override
    public void deleteRolePermissions(String rid) throws Exception {
        String sql="delete from role_permission where roleid=?";
        template.update(sql,rid);
    }

    @Override
    public void deleteById(String rid) throws Exception {
        String sql="delete from role where id=?";
        template.update(sql,rid);
    }

    @Override
    public List<Permission> findRolePermissions(String rid) throws Exception {
        String sql = "select * from permission where id in(select permissionId  FROM role_permission where roleId=?)";
        return template.query(sql,new BeanPropertyRowMapper<Permission>(Permission.class),rid);
    }
    //操作role-permiss表，增加一条数据
    @Override
    public void addRolePermission(String roleId, String pid) {
        String sql = "insert into  role_permission values (?,?)";
        template.update(sql,pid,roleId);
    }
}
