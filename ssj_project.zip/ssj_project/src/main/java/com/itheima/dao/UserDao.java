package com.itheima.dao;

import com.itheima.domain.Role;
import com.itheima.domain.User;

import java.util.List;

public interface UserDao {
    List<User> findAll() throws Exception;

    void save(User user) throws Exception;

    List<Role> findUserRoles(String uid)throws Exception;

    void addUserRole(String userId, String roleId)throws Exception;

    void deleteUserRoles(String userId)throws Exception;

    void deleteUserById(String uid)throws Exception;

    User findUserById(String uid)throws Exception;

    User finUserByUsernamePwd(String username, String password)throws Exception;
}
