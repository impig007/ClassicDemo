package com.itheima.web.controller;

import com.itheima.domain.Permission;
import com.itheima.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/permission")
public class PermissionController {


    @Autowired
    private PermissionService permissionService;

    //删除选中
    @RequestMapping("/deleteBySelected")
    public String deleteBySelected(String pids) throws Exception {
        permissionService.deleteBySelected(pids);
        //删除之后再次查询所有
        return "redirect:findAll";
    }


    @RequestMapping("/permissionDetail")
    public String permissionDetail(String pid,Model model) throws Exception {
        Permission permission = permissionService.findPermissionById(pid);
        model.addAttribute("permission",permission);
        System.out.println(permission);
        return "permission-show";
    }



    @RequestMapping("/findAll")
    public String findAll(Model model) throws Exception {
        List<Permission> permissionList = permissionService.findAll();
        model.addAttribute("permissionList",permissionList);
        return "permission-list";
    }
    //添加权限
    @RequestMapping("/save")
    public String save(Permission permission) throws Exception {
        permissionService.save(permission);
        //内部方法之间的跳转，因为你已经在user下了，所以无需加user
        return "redirect:findAll";
    }
}
