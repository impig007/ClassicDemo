package com.itheima.web.controller;

import com.itheima.domain.Permission;
import com.itheima.domain.Role;
import com.itheima.service.PermissionService;
import com.itheima.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;


@Controller
@RequestMapping("/role")
public class RoleController {

    @Autowired
    private RoleService roleService;
    @Autowired
    private PermissionService permissionService;
    @RequestMapping("/deleteRole")
    public String deleteRole(String rid) throws Exception {
        roleService.deleteRoleById(rid);
        return "redirect:findAll";
    }

    @RequestMapping("/roleDetail")
    public String roleDetail(String rid,Model model) throws Exception {
        Role role = roleService.findRoleById(rid);
        model.addAttribute("role",role);
        System.out.println("roledetail"+role);
        return "role-show";
    }

    @RequestMapping("/findAll")
    public String findAll(Model model) throws Exception {
        List<Role> roleList = roleService.findAllRole();
        model.addAttribute("roleList",roleList);
        return "role-list";
    }
    @RequestMapping("/save")
    public String save(Role role) throws Exception {
        roleService.save(role);
        return "redirect:/role/findAll";
    }
    @RequestMapping("/findRolePermissions")
    public String findRolePermissions(String rid,Model model) throws Exception {
        //查找所有的权限
        List<Permission> permissionList= permissionService.findAll();
        //查找所有角色对应的权限s
        List<Permission> allRolePermissions = roleService.findRolePermissions(rid);
        for (Permission permission : permissionList) {
            for (Permission rolePermission : allRolePermissions) {
                if (rolePermission.getId().equals(permission.getId())){
                    permission.setFlag(1);
                }
            }
        }
        model.addAttribute("permissionList",permissionList);
        //为了将来返回的界面上能取到id所以存入id值(此方法是中间方法，将传来的id响应给界面)
        model.addAttribute("rid",rid);
        return "role-permission-add";
    }
    @RequestMapping("/updateRolePermissions")
    public String updateRolePermissions(String roleId,String[] ids) throws Exception {
        //在role-user表中更新数据
        roleService.updateRolePermissions(roleId,ids);
        //更新结束，在此跳转查询方法
        return "redirect:findAll";
    }
}
