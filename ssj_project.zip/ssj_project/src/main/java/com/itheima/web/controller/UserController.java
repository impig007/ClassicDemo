package com.itheima.web.controller;

import com.itheima.dao.UserDao;
import com.itheima.dao.impl.UserDaoImpl;
import com.itheima.domain.Role;
import com.itheima.domain.User;
import com.itheima.exception.MyException;
import com.itheima.service.RoleService;
import com.itheima.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;
    @Autowired
    private RoleService roleService;
    @RequestMapping("/UserDetail")
    public String UserDetail(String uid,Model model) throws Exception {
        User user = userService.findUserById(uid);
        model.addAttribute("user",user);
        return "user-show";
    }
    //删除选中
    @RequestMapping("/deleteBySelected")
    public String deleteBySelected(String uids) throws Exception {
        userService.deleteBySelected(uids);
        //删除之后再次查询所有
        return "redirect:findAll";
    }

    //更新用户对应角色信息
    @RequestMapping("/updateUserRoles")
    public String updateUserRoles(String userId,String[] ids) throws Exception {
        //在role-user表中更新数据
        userService.updateUserRoles(userId,ids);
        //更新结束，在此跳转查询方法
        return "redirect:findAll";
    }



    //查找用户对应的角色（可能有多个）
    @RequestMapping("/findUserRoles")
    public String findUserRoles(String uid,Model model) throws Exception {
        List<Role> roleList  = roleService.findAllRole();
        List<Role> allUserRoles = userService.findUserRoles(uid);
        for (Role role : roleList) {
            for (Role userRole : allUserRoles) {
                if (userRole.getId().equals(role.getId())){
                    role.setFlag(1);
                }
            }
        }
        model.addAttribute("roleList",roleList);
        //为了将来返回的界面上能取到id所以存入id值(此方法是中间方法，将传来的id响应给界面)
        model.addAttribute("uid",uid);
        return "user-role-add";
    }



    //查找所有用户
    @RequestMapping("/findAll")
    public String findAll(Model model) throws Exception {
        List<User> userList =userService.findAll();
        System.out.println(userList);
        model.addAttribute("userList",userList);
        //跳转到物理视图指定界面，最后是一个绝对路径
        return "user-list";
    }
    //保存单个用户
    @RequestMapping("/save")
    public String save(User user) throws Exception {
        userService.save(user);
        //内部方法之间的跳转，因为你已经在user下了，所以无需加user
        return "redirect:findAll";
    }

    //根据用户名和密码实现登陆操作

    @RequestMapping("/login")
    public String login(String rememberme, String username, String password, HttpServletRequest request, HttpServletResponse response) throws Exception {
        User user = userService.login(username,password);
        if(user != null){
            //登录成功
            //将用户存入session
            request.getSession().setAttribute("user",user);
            //增加自动登陆功能
            String autoLogin = request.getParameter("rememberme");
            if (autoLogin!=null){
                //勾选了自动登陆,将用户名和密码存入cookie并持久化
                String autoLoginCookie = username+"@"+password;
                Cookie cookie = new Cookie("autoLoginCookie",autoLoginCookie);
                cookie.setMaxAge(24*60*60);
                //这里response之后无法进行下一步操作了
                response.addCookie(cookie);
            }
            //跳转页面
            return "redirect:/index.jsp";
        }else{
            //登录失败
            //跳转登录页面
            return "redirect:/pages/login.jsp";
        }

    }

//
//    @RequestMapping("exceptionDemo1")
//    public void exceptionDemo1(){
//        UserService service = (UserService) new UserDaoImpl();
//        throw new MyException();
//
//    }
}
